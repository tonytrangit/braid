-- Braid review service. One database can hold several reviews; each has its own host key (stored as a hash).
-- expires_at closes the review to clients; the host (Braid) keeps access until purge_after to sync picks back.
CREATE TABLE IF NOT EXISTS reviews (id TEXT PRIMARY KEY, title TEXT NOT NULL, expires_at INTEGER NOT NULL, purge_after INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'open', version INTEGER NOT NULL DEFAULT 1, host_hash TEXT NOT NULL, manifest TEXT NOT NULL DEFAULT '{}', starting TEXT, identities TEXT, checksums TEXT, last_client_edit INTEGER, mark_seq INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS invites (id TEXT PRIMARY KEY, review_id TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, role TEXT NOT NULL CHECK (role IN ('view','pick')), label TEXT NOT NULL, expires_at INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions (id_hash TEXT PRIMARY KEY, invite_id TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS marks (review_id TEXT NOT NULL, variant_key TEXT NOT NULL, field TEXT NOT NULL CHECK (field IN ('rating','color')), value INTEGER NOT NULL, rev INTEGER NOT NULL DEFAULT 1, seq INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (review_id, variant_key, field));
-- Marks changed since a cursor, read through this index (seq advances with every committed change).
CREATE INDEX IF NOT EXISTS marks_seq ON marks (review_id, seq);
-- Every change, by a reviewer or by the host (Braid): the operation itself (its value, the revision it was based on and the one it
-- created), committed in the same transaction as the change. Request ids are unique per review and sender.
CREATE TABLE IF NOT EXISTS journal (request_id TEXT NOT NULL, review_id TEXT NOT NULL, actor TEXT NOT NULL, variant_key TEXT NOT NULL, field TEXT NOT NULL, old_value INTEGER, new_value INTEGER NOT NULL, base_rev INTEGER NOT NULL, new_rev INTEGER NOT NULL, at INTEGER NOT NULL, network TEXT, PRIMARY KEY (review_id, actor, request_id));
-- Request ids abandoned by their sender after a lost reply: such a request can never commit later.
CREATE TABLE IF NOT EXISTS fences (review_id TEXT NOT NULL, actor TEXT NOT NULL, request_id TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY (review_id, actor, request_id));
-- Never holds a row: a batch that must not commit under some condition starts by inserting NULL here when it holds, which
-- fails the constraint and rolls the whole batch back (D1 batches are one transaction).
CREATE TABLE IF NOT EXISTS batch_guard (must_be_null INTEGER NOT NULL);

-- Hosted mode uses private SQLite-backed Durable Objects. Reservations count against the configured Braid budget
-- before a shard stores the image, including during concurrent uploads or a retry after a lost reply.
CREATE TABLE IF NOT EXISTS hosted_storage (id INTEGER PRIMARY KEY CHECK (id = 1), reserved_bytes INTEGER NOT NULL DEFAULT 0);
INSERT OR IGNORE INTO hosted_storage (id) VALUES (1);
CREATE TABLE IF NOT EXISTS hosted_uploads (
  review_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('t','p')),
  name TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  bytes INTEGER NOT NULL CHECK (bytes > 0),
  stored INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (review_id, kind, name)
);
CREATE TRIGGER IF NOT EXISTS hosted_upload_reserved AFTER INSERT ON hosted_uploads BEGIN
  UPDATE hosted_storage SET reserved_bytes = reserved_bytes + NEW.bytes WHERE id = 1;
END;
CREATE TRIGGER IF NOT EXISTS hosted_upload_released AFTER DELETE ON hosted_uploads BEGIN
  UPDATE hosted_storage SET reserved_bytes = reserved_bytes - OLD.bytes WHERE id = 1;
END;
-- Guests can read only the content names in the current manifest. This index is replaced atomically with it.
CREATE TABLE IF NOT EXISTS hosted_manifest_files (
  review_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('t','p')),
  name TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  PRIMARY KEY (review_id, kind, name)
);

-- The permanent review-ID fence. An absent ID is new, and a retired ID is never reused.
-- due_at is draft inactivity, the committed review's purge time, or the next sweep attempt.
CREATE TABLE IF NOT EXISTS hosted_lifecycle (
  review_id TEXT PRIMARY KEY,
  state TEXT NOT NULL DEFAULT 'live' CHECK (state IN ('live','retiring','retired')),
  committed INTEGER NOT NULL DEFAULT 0 CHECK (committed IN (0,1)),
  due_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS hosted_lifecycle_due ON hosted_lifecycle (state, due_at, review_id);
CREATE INDEX IF NOT EXISTS review_invites ON invites (review_id);
CREATE INDEX IF NOT EXISTS invite_sessions ON sessions (invite_id);

-- Additive backfill. Established reviews keep their real purge time (never before their existing expiry).
-- Old upload-only and draft rows have no activity timestamp, so give them seven days from migration.
INSERT OR IGNORE INTO hosted_lifecycle (review_id, committed, due_at)
SELECT id, EXISTS (SELECT 1 FROM invites WHERE review_id = r.id),
  CASE WHEN EXISTS (SELECT 1 FROM invites WHERE review_id = r.id) THEN max(purge_after, expires_at)
       ELSE max(created_at, CAST(strftime('%s','now') AS INTEGER) * 1000) + 604800000 END
  FROM reviews r;
INSERT OR IGNORE INTO hosted_lifecycle (review_id, due_at)
SELECT DISTINCT review_id, CAST(strftime('%s','now') AS INTEGER) * 1000 + 604800000 FROM hosted_uploads;

-- The shards are empty. Payload reservations can now be released in bounded batches even after interruption.
CREATE TABLE IF NOT EXISTS hosted_cleaned_storage (review_id TEXT PRIMARY KEY);
