// Braid review service. Every request (pages, data and images) runs here first: nothing is served
// without a valid, unrevoked, unexpired invite session. Marks change only against the revision the reviewer saw.
// Three kinds of caller:
//   admin  - Braid on the photographer's Mac, with the installation's admin key: creates reviews.
//   host   - Braid with one review's host key: reads and updates marks, manages invites, expires the review. Keeps
//            working after the review closes to clients, until its purge date, so picks can still be synced back.
//   client - a browser with an invite session: sees only that review's gallery, images and marks.
const enc = new TextEncoder();
const PRIVATE = { 'Cache-Control': 'private, no-store', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff' };
const CSP = "default-src 'self'; img-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";

async function sha256(s) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(s));
  return hexBytes(d);
}
export function hexBytes(bytes) {
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function randomToken(bytes = 32) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a);
  return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function json(body, status = 200, extra = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...PRIVATE, ...extra } });
}
function cookie(req, name) {
  const m = (req.headers.get('Cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? m[1] : null;
}
function sameOrigin(req, url) { return req.headers.get('Origin') === url.origin; }
async function asset(env, req, url, path, extraHeaders = {}) {
  const r = await env.ASSETS.fetch(new Request(new URL(path, url), { headers: req.headers }));
  const h = new Headers(r.headers);
  for (const [k, v] of Object.entries({ ...PRIVATE, ...extraHeaders })) h.set(k, v);
  return new Response(r.body, { status: r.status, headers: h });
}

async function sessionFor(req, env) {
  const sid = cookie(req, 'brs');
  if (!sid) return null;
  const row = await env.DB.prepare(
    `SELECT s.invite_id, i.role, i.label, i.revoked, i.expires_at AS iexp, r.id AS review_id, r.title, r.expires_at AS rexp, r.status, r.version
       FROM sessions s JOIN invites i ON i.id = s.invite_id JOIN reviews r ON r.id = i.review_id WHERE s.id_hash = ?`
  ).bind(await sha256(sid)).first();
  if (!row) return null;
  const now = Date.now();
  if (row.revoked) return { denied: 'revoked' };
  if (row.status !== 'open') return { denied: 'closed' };
  if (now > row.iexp || now > row.rexp || await hostedIsRetired(env, row.review_id)) return { denied: 'expired' };
  return row;
}

// Marks changed since a cursor, in pages. Every committed change gives the mark the review's next sequence number (in
// the same transaction), so a reader that keeps the last cursor it saw never misses or double-counts a change, and an
// idle poll reads no mark rows at all. since=-1 (or absent) reads from the beginning.
async function marksSince(env, reviewId, url) {
  const since = Math.max(-1, parseInt(url.searchParams.get('since') || '-1', 10) || -1);
  const limit = Math.min(2000, Math.max(1, parseInt(url.searchParams.get('limit') || '2000', 10) || 2000));
  const { results } = await env.DB.prepare('SELECT variant_key AS k, field AS f, value AS v, rev AS r, seq AS s FROM marks WHERE review_id = ? AND seq > ? ORDER BY seq LIMIT ?')
    .bind(reviewId, since, limit + 1).all();
  const more = results.length > limit;
  const page = more ? results.slice(0, limit) : results;
  return { marks: page, cursor: page.length ? page[page.length - 1].s : since, more };
}

function validMark(b) {
  if (!b || typeof b.key !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(b.key)) return false;
  if (!['rating', 'color'].includes(b.field)) return false;
  const max = b.field === 'rating' ? 5 : 7;
  if (!Number.isInteger(b.value) || b.value < 0 || b.value > max) return false;
  return Number.isInteger(b.baseRev) && typeof b.requestId === 'string' && /^[A-Za-z0-9_-]{16,64}$/.test(b.requestId);
}

// One change by one sender (a reviewer's invite, or the host), revision-checked.
// - The history entry is the operation: the update applies only that entry's value, and only from its base revision,
//   and both are committed in one transaction (one D1 batch) or not at all.
// - Request ids are scoped to the review and the sender. A retry gets the exact receipt of the commit (its value and
//   the revision it created), never the current state; reusing an id for different content is refused.
async function commitMark(env, reviewId, actor, network, b) {
  const op = 'review_id = ? AND actor = ? AND request_id = ?';
  const receipt = async () => {
    const r = await env.DB.prepare(`SELECT variant_key, field, new_value, base_rev, new_rev FROM journal WHERE ${op}`)
      .bind(reviewId, actor, b.requestId).first();
    if (!r) return null;
    if (r.variant_key !== b.key || r.field !== b.field || r.new_value !== b.value || r.base_rev !== b.baseRev) {
      return json({ error: 'request-reused' }, 422);
    }
    return json({ ok: true, value: r.new_value, rev: r.new_rev, requestId: b.requestId });
  };
  try {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    const earlier = await receipt();
    if (earlier) return earlier;
    const where = 'review_id = ? AND variant_key = ? AND field = ?';
    const mine = 'j.review_id = marks.review_id AND j.variant_key = marks.variant_key AND j.field = marks.field AND j.actor = ? AND j.request_id = ?';
    const at = Date.now();
    const stmts = [
      env.DB.prepare(`INSERT INTO journal (request_id, review_id, variant_key, field, old_value, new_value, base_rev, new_rev, actor, at, network)
                      SELECT ?, review_id, variant_key, field, value, ?, rev, rev + 1, ?, ?, ? FROM marks WHERE ${where} AND rev = ? AND value <> ?
                      AND NOT EXISTS (SELECT 1 FROM fences f WHERE f.review_id = ? AND f.actor = ? AND f.request_id = ?)`)
        .bind(b.requestId, b.value, actor, at, network, reviewId, b.key, b.field, b.baseRev, b.value, reviewId, actor, b.requestId),
      env.DB.prepare(`UPDATE reviews SET mark_seq = mark_seq + 1 WHERE id = ? AND EXISTS (SELECT 1 FROM journal WHERE ${op})`)
        .bind(reviewId, reviewId, actor, b.requestId),
      env.DB.prepare(`UPDATE marks SET value = (SELECT j.new_value FROM journal j WHERE ${mine}), rev = rev + 1, seq = (SELECT mark_seq FROM reviews WHERE id = ?)
                      WHERE ${where} AND rev = (SELECT j.base_rev FROM journal j WHERE ${mine})`)
        .bind(actor, b.requestId, reviewId, reviewId, b.key, b.field, actor, b.requestId),
    ];
    // When a client last changed a mark ("last online edit" in Braid), kept with the change itself so Braid reads it
    // with its ordinary incremental read instead of scanning the history.
    if (actor.startsWith('invite:')) stmts.push(env.DB.prepare(`UPDATE reviews SET last_client_edit = ? WHERE id = ? AND EXISTS (SELECT 1 FROM journal WHERE ${op})`)
      .bind(at, reviewId, reviewId, actor, b.requestId));
    if (env.REVIEW_IMAGES) stmts.unshift(hostedLiveGuard(env, reviewId));
    await env.DB.batch(stmts);
  } catch (e) {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    // For example a concurrent retry of the same request committed first (its history entry already exists).
    try { const r = await receipt(); if (r) return r; } catch (_) {}
    return json({ error: 'not-saved' }, 503);
  }
  try {
    const r = await receipt();
    if (r) return r;
    const fenced = await env.DB.prepare('SELECT 1 AS x FROM fences WHERE review_id = ? AND actor = ? AND request_id = ?').bind(reviewId, actor, b.requestId).first();
    if (fenced) return json({ error: 'fenced' }, 410);
    const cur = await env.DB.prepare('SELECT value, rev FROM marks WHERE review_id = ? AND variant_key = ? AND field = ?').bind(reviewId, b.key, b.field).first();
    if (!cur) return json({ error: 'unknown-image' }, 404);
    if (cur.rev === b.baseRev && cur.value === b.value) return json({ ok: true, value: cur.value, rev: cur.rev, noop: true });
    return json({ conflict: true, value: cur.value, rev: cur.rev }, 409);
  } catch (e) {
    return json({ error: 'not-saved' }, 503);
  }
}

// Recovery for a request whose reply was lost: returns its committed receipt, or (if it never committed) fences the
// request id first, atomically, so a delayed delivery of the abandoned request can't commit afterwards.
async function settleMark(env, reviewId, actor, b) {
  const op = 'review_id = ? AND actor = ? AND request_id = ?';
  try {
    const insert = env.DB.prepare(`INSERT OR IGNORE INTO fences (review_id, actor, request_id, at) SELECT ?, ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM journal WHERE ${op})`)
      .bind(reviewId, actor, b.requestId, Date.now(), reviewId, actor, b.requestId);
    if (env.REVIEW_IMAGES) await env.DB.batch([hostedLiveGuard(env, reviewId), insert]);
    else await insert.run();
    const r = await env.DB.prepare(`SELECT variant_key, field, new_value, base_rev, new_rev FROM journal WHERE ${op}`).bind(reviewId, actor, b.requestId).first();
    if (r) {
      if (r.variant_key !== b.key || r.field !== b.field || r.new_value !== b.value || r.base_rev !== b.baseRev) return json({ error: 'request-reused' }, 422);
      return json({ committed: true, value: r.new_value, rev: r.new_rev });
    }
    return json({ fenced: true });
  } catch (e) {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    return json({ error: 'not-saved' }, 503);
  }
}

function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i); return x === 0;
}
async function isAdmin(req, env) {
  const auth = req.headers.get('Authorization') || '';
  return !!env.ADMIN_KEY_HASH && auth.startsWith('Bearer ') && safeEqual(await sha256(auth.slice(7)), env.ADMIN_KEY_HASH);
}
const ID = /^[A-Za-z0-9_-]{8,64}$/;
const HEX = /^[0-9a-f]{64}$/;
const CONTENT_NAME = /^[A-Za-z0-9_-]{8,47}-[0-9a-f]{16}$/;
// Stay below SQLite's 8 MB limit for the complete row, including its keys and metadata.
export const MAX_HOSTED_IMAGE_BYTES = 7 * 1024 * 1024;
const MAX_HOSTED_BUDGET_BYTES = 4_000_000_000;
const IMAGE_SHARDS = 16;

const DRAFT_LIFETIME_MS = 7 * 86400000;
const SWEEP_RETRY_MS = 60000;
const SWEEP_DATA_BATCH = 200;

function refreshHostedDraft(env, id, now) {
  return env.DB.prepare(`INSERT INTO hosted_lifecycle (review_id, due_at) VALUES (?, ?)
    ON CONFLICT(review_id) DO UPDATE SET due_at = max(hosted_lifecycle.due_at, excluded.due_at)
    WHERE hosted_lifecycle.state = 'live' AND hosted_lifecycle.committed = 0`).bind(id, now + DRAFT_LIFETIME_MS);
}
function hostedLiveGuard(env, id) {
  return env.DB.prepare(`INSERT INTO batch_guard (must_be_null) SELECT NULL WHERE NOT EXISTS (
    SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')`).bind(id);
}
async function hostedIsRetired(env, id) {
  if (!env.REVIEW_IMAGES) return false;
  const row = await env.DB.prepare("SELECT state FROM hosted_lifecycle WHERE review_id = ? AND state <> 'live'").bind(id).first();
  return !!row;
}
function retiredResponse() { return json({ error: 'review-retired' }, 410); }
// Shard on the variant key, so a gallery of identical JPEGs still spreads across objects.
export function imageShard(name) {
  let hash = 2166136261;
  for (let i = 0; i < name.length - 17; ++i) hash = Math.imul(hash ^ name.charCodeAt(i), 16777619);
  return (hash >>> 0) % IMAGE_SHARDS;
}
function imageStore(env, id, shard) {
  return env.REVIEW_IMAGES.get(env.REVIEW_IMAGES.idFromName(`${id}/${shard}`));
}


function hostedBudget(env) {
  const bytes = Number(env.BRAID_STORAGE_BUDGET_BYTES);
  return Number.isSafeInteger(bytes) && bytes > 0 && bytes <= MAX_HOSTED_BUDGET_BYTES ? bytes : null;
}

async function hostedCapacity(env, reviewID, req) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  let requestedBytes = 0;
  if (reviewID) {
    if (await hostedIsRetired(env, reviewID)) return retiredResponse();
    const files = await req.json().catch(() => null);
    if (!Array.isArray(files) || files.length > 10000 || !files.every(f => Array.isArray(f) && f.length === 3 &&
        (f[0] === 't' || f[0] === 'p') && typeof f[1] === 'string' && CONTENT_NAME.test(f[1]) &&
        Number.isSafeInteger(f[2]) && f[2] >= 4 && f[2] <= 100000000)) return json({ error: 'bad-request' }, 400);
    const sum = await env.DB.prepare(`SELECT coalesce(sum(bytes), 0) AS required FROM (
      SELECT DISTINCT json_extract(value, '$[0]') AS kind, json_extract(value, '$[1]') AS name,
      json_extract(value, '$[2]') AS bytes FROM json_each(?)
    ) AS proposed WHERE NOT EXISTS (
      SELECT 1 FROM hosted_uploads WHERE review_id = ? AND kind = proposed.kind AND name = proposed.name AND bytes = proposed.bytes
    )`).bind(JSON.stringify(files), reviewID).first();
    requestedBytes = sum.required;
  }
  const usage = await env.DB.prepare('SELECT reserved_bytes FROM hosted_storage WHERE id = 1').first();
  return json({ budgetBytes: budget, reservedBytes: usage.reserved_bytes, availableBytes: Math.max(0, budget - usage.reserved_bytes),
    maxImageBytes: MAX_HOSTED_IMAGE_BYTES, requestedBytes });
}

async function uploadHostedImage(req, env, reviewID, kind, name) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  const size = Number(req.headers.get('Content-Length'));
  const digest = req.headers.get('X-Braid-SHA256') || '';
  if (!CONTENT_NAME.test(name) || !HEX.test(digest) || !name.endsWith('-' + digest.slice(0, 16))) return json({ error: 'bad-content-name' }, 400);
  if (req.headers.get('Content-Type') !== 'image/jpeg' || !Number.isSafeInteger(size) || size < 4) return json({ error: 'bad-image' }, 400);
  if (size > MAX_HOSTED_IMAGE_BYTES) return json({ error: 'image-too-large' }, 413);
  const headers = { 'Content-Length': String(size), 'X-Braid-SHA256': digest };
  if (req.headers.get('X-Braid-Repair') === '1') headers['X-Braid-Repair'] = '1';
  try {
    return await imageStore(env, reviewID, imageShard(name)).fetch(new Request(
      `https://review-storage.internal/objects/${reviewID}/${kind}/${name}`, { method: 'PUT', headers, body: req.body, duplex: 'half' }));
  } catch {
    return json({ error: 'retry-upload' }, 503);
  }
}

// Called by the private image shard after it has verified the body, while holding its serialization queue.
export async function reserveHostedImage(env, reviewID, kind, name, digest, size, repair) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  if (await storageReviewState(env, reviewID) === 'closed') return json({ error: 'files-deleted' }, 410);
  if (await hostedIsRetired(env, reviewID)) return retiredResponse();
  if (repair) {
    const committed = await env.DB.prepare(`SELECT 1 AS ok FROM hosted_manifest_files
      WHERE review_id = ? AND kind = ? AND name = ? AND sha256 = ?
      AND EXISTS (SELECT 1 FROM invites WHERE review_id = ?)`).bind(reviewID, kind, name, digest, reviewID).first();
    if (!committed) return json({ error: 'repair-not-committed' }, 409);
  }

  // Refresh and reserve in one D1 transaction. Once the retirement fence wins, this ID cannot gain a reservation.
  await env.DB.batch([refreshHostedDraft(env, reviewID, Date.now()), env.DB.prepare(`INSERT INTO hosted_uploads (review_id, kind, name, sha256, bytes)
    SELECT ?, ?, ?, ?, ? FROM hosted_storage WHERE id = 1 AND reserved_bytes <= ? - ?
    AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')
    AND NOT EXISTS (SELECT 1 FROM reviews WHERE id = ? AND status = 'closed')
    ON CONFLICT(review_id, kind, name) DO NOTHING`).bind(reviewID, kind, name, digest, size, budget, size, reviewID, reviewID)]);
  const reservation = await env.DB.prepare(`SELECT u.sha256, u.bytes FROM hosted_uploads u
    JOIN hosted_lifecycle l USING (review_id) WHERE u.review_id = ? AND u.kind = ? AND u.name = ? AND l.state = 'live'`)
    .bind(reviewID, kind, name).first();
  if (!reservation && await hostedIsRetired(env, reviewID)) return retiredResponse();
  if (!reservation) return json({ error: 'storage-budget-exceeded' }, 409);
  if (reservation.sha256 !== digest || reservation.bytes !== size) return json({ error: 'content-conflict' }, 409);

  return null;
}

export async function settleHostedImage(env, reviewID, kind, name) {
  await env.DB.prepare(`UPDATE hosted_uploads SET stored = 1 WHERE review_id = ? AND kind = ? AND name = ? AND stored = 0
    AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')`).bind(reviewID, kind, name, reviewID).run();
  if (await hostedIsRetired(env, reviewID)) return retiredResponse();
  return json({ ok: true });
}

export async function storageReviewState(env, reviewID) {
  return (await env.DB.prepare(`SELECT CASE WHEN l.state = 'live' AND r.status = 'closed' THEN 'closed' ELSE l.state END AS state
    FROM hosted_lifecycle l LEFT JOIN reviews r ON r.id = l.review_id WHERE l.review_id = ?`).bind(reviewID).first())?.state;
}

async function reviewImage(env, req, url, reviewID, kind, name, localCache = {}) {
  if (!env.REVIEW_IMAGES) return asset(env, req, url, `/reviews/${reviewID}/${kind}/${name}.jpg`, localCache);
  const file = await env.DB.prepare(`SELECT f.sha256 FROM hosted_manifest_files f JOIN hosted_lifecycle l USING(review_id)
    WHERE f.review_id = ? AND f.kind = ? AND f.name = ? AND l.state = 'live'
    AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.id = f.review_id AND r.status = 'closed')`)
    .bind(reviewID, kind, name).first();
  if (!file) return json({ error: 'not-found' }, 404);
  try {
    return await imageStore(env, reviewID, imageShard(name)).fetch(new Request(
      `https://review-storage.internal/objects/${reviewID}/${kind}/${name}`, { headers: { 'X-Braid-SHA256': file.sha256 } }));
  } catch {
    return json({ error: 'storage-unavailable' }, 503);
  }
}

// A new review: its gallery data (collections and images) and the starting marks, saved together.
async function createReview(env, b) {
  if (!b || !ID.test(b.id || '') || typeof b.title !== 'string' || !b.title || b.title.length > 200) return json({ error: 'bad-request' }, 400);
  if (!/^[0-9a-f]{64}$/.test(b.hostKeyHash || '') || !Number.isInteger(b.expiresAt) || !Number.isInteger(b.purgeAfter) || b.purgeAfter < b.expiresAt) return json({ error: 'bad-request' }, 400);
  const m = b.manifest;
  if (!m || !Array.isArray(m.images) || !Array.isArray(m.collections) || !Array.isArray(b.marks)) return json({ error: 'bad-request' }, 400);
  const keys = new Set(m.images.map(i => i.key));
  if (keys.size !== m.images.length || ![...keys].every(k => ID.test(k))) return json({ error: 'bad-request' }, 400);
  // Host-only fingerprint of what each key was rendered from (a hash of the variant and its original): lets a resumed
  // share check it is still publishing the same images. Never sent to clients.
  const ids = b.identities;
  if (!ids || typeof ids !== 'object' || Object.keys(ids).length !== keys.size || ![...keys].every(k => /^[0-9a-f]{64}$/.test(ids[k] || ''))) return json({ error: 'bad-request' }, 400);
  // The gallery's files: each image names its grid tile and viewer image, and every file's sha256 is committed with the
  // manifest (host-only), so a resumed share can check exactly what is published.
  const sums = b.checksums, NAME = /^[A-Za-z0-9_-]{8,64}$/;
  if (!sums || typeof sums !== 'object' || !m.images.every(i => NAME.test(i.thumb || '') && NAME.test(i.preview || '') && HEX.test(sums[i.thumb] || '') && HEX.test(sums[i.preview] || ''))) return json({ error: 'bad-request' }, 400);
  const hostedFiles = env.REVIEW_IMAGES ? m.images.flatMap(i => [['t', i.thumb, sums[i.thumb]], ['p', i.preview, sums[i.preview]]]) : [];
  if (env.REVIEW_IMAGES && (!hostedFiles.length || !m.images.every(i => i.thumb === i.key + '-' + sums[i.thumb].slice(0, 16) &&
      i.preview === i.key + '-' + sums[i.preview].slice(0, 16)))) return json({ error: 'bad-content-name' }, 400);
  const hostedFilesJSON = JSON.stringify(hostedFiles);
  const missingFiles = () => env.DB.prepare(`SELECT 1 AS missing FROM json_each(?) AS file WHERE NOT EXISTS (
    SELECT 1 FROM hosted_uploads WHERE review_id = ?
    AND kind = json_extract(file.value, '$[0]') AND name = json_extract(file.value, '$[1]')
    AND sha256 = json_extract(file.value, '$[2]') AND stored = 1) LIMIT 1`).bind(hostedFilesJSON, b.id).first();
  for (const x of b.marks) if (!keys.has(x.k) || !Number.isInteger(x.rating) || x.rating < 0 || x.rating > 5 || !Number.isInteger(x.color) || x.color < 0 || x.color > 7) return json({ error: 'bad-request' }, 400);
  // An existing review can be replaced only while it is still a draft (no invite yet) and by the same host key: a retry
  // after a failed check republishes the photographer's current images and marks. Once an invite exists it's committed.
  // The early check is only a shortcut: the replacement batch itself starts with a guard that fails (rolling the whole
  // batch back) if an invite exists or the host key differs at commit time, so an invite created meanwhile always wins.
  const committedOrForeign = async () => {
    const e = await env.DB.prepare('SELECT host_hash, (SELECT count(*) FROM invites WHERE review_id = reviews.id) AS invites FROM reviews WHERE id = ?').bind(b.id).first();
    return e && (e.invites > 0 || e.host_hash !== b.hostKeyHash) ? e : null;
  };
  if (await hostedIsRetired(env, b.id)) return retiredResponse();
  if (await committedOrForeign()) return json({ error: 'exists' }, 409);
  if (hostedFiles.length && await missingFiles()) return json({ error: 'missing-upload' }, 422);
  const existing = await env.DB.prepare('SELECT 1 AS x FROM reviews WHERE id = ?').bind(b.id).first();
  const now = Date.now();
  const rows = b.marks.flatMap(x => [[x.k, 'rating', x.rating], [x.k, 'color', x.color]]);
  const starting = JSON.stringify(b.marks.map(x => ({ k: x.k, rating: x.rating, color: x.color })));
  const identities = JSON.stringify(ids);
  const checksums = JSON.stringify(Object.fromEntries(m.images.flatMap(i => [[i.thumb, sums[i.thumb]], [i.preview, sums[i.preview]]])));
  const stmts = existing
    ? [env.DB.prepare(`INSERT INTO batch_guard (must_be_null) SELECT NULL WHERE EXISTS (SELECT 1 FROM invites WHERE review_id = ?)
                       OR NOT EXISTS (SELECT 1 FROM reviews WHERE id = ? AND host_hash = ?)`).bind(b.id, b.id, b.hostKeyHash),
       env.DB.prepare('DELETE FROM marks WHERE review_id = ?').bind(b.id), env.DB.prepare('DELETE FROM journal WHERE review_id = ?').bind(b.id),
       env.DB.prepare('UPDATE reviews SET title = ?, expires_at = ?, purge_after = ?, manifest = ?, starting = ?, identities = ?, checksums = ?, mark_seq = ? WHERE id = ?')
         .bind(b.title, b.expiresAt, b.purgeAfter, JSON.stringify(m), starting, identities, checksums, rows.length, b.id)]
    : [env.DB.prepare('INSERT INTO reviews (id, title, expires_at, purge_after, status, version, host_hash, manifest, starting, identities, checksums, mark_seq, created_at) VALUES (?, ?, ?, ?, \'open\', 1, ?, ?, ?, ?, ?, ?, ?)')
         .bind(b.id, b.title, b.expiresAt, b.purgeAfter, b.hostKeyHash, JSON.stringify(m), starting, identities, checksums, rows.length, now)];
  for (let i = 0; i < rows.length; i += 20) {
    const part = rows.slice(i, i + 20);
    stmts.push(env.DB.prepare('INSERT INTO marks (review_id, variant_key, field, value, rev, seq) VALUES ' + part.map(() => '(?, ?, ?, ?, 1, ?)').join(', '))
      .bind(...part.flatMap((r, j) => [b.id, ...r, i + j + 1])));
  }
  if (hostedFiles.length) {
    stmts.unshift(refreshHostedDraft(env, b.id, now), hostedLiveGuard(env, b.id));
    stmts.push(env.DB.prepare('DELETE FROM hosted_manifest_files WHERE review_id = ?').bind(b.id),
      env.DB.prepare(`INSERT INTO hosted_manifest_files (review_id, kind, name, sha256)
        SELECT ?, json_extract(value, '$[0]'), json_extract(value, '$[1]'), json_extract(value, '$[2]') FROM json_each(?)`)
        .bind(b.id, hostedFilesJSON));
  }
  try { await env.DB.batch(stmts); }
  catch (e) {
    // The guard (an invite was created, or another key took the id, between the check and the batch), or a concurrent
    // first create of the same id: nothing was changed.
    if (await hostedIsRetired(env, b.id)) return retiredResponse();
    if (await committedOrForeign()) return json({ error: 'exists' }, 409);
    throw e;
  }
  return json({ ok: true, id: b.id, replaced: !!existing });
}

async function hostManage(req, env, r, action) {
  const now = Date.now();
  if (action === 'status' && req.method === 'GET') {
    const inv = await env.DB.prepare('SELECT id, label, role, expires_at AS expiresAt, revoked FROM invites WHERE review_id = ? ORDER BY rowid').bind(r.id).all();
    return json({ id: r.id, title: r.title, expiresAt: r.expires_at, purgeAfter: r.purge_after, status: r.status, open: r.status === 'open' && now <= r.expires_at,
                  invites: inv.results, lastClientEditAt: r.last_client_edit || null });
  }
  if (action === 'committed' && req.method === 'GET') {
    // What a resumed share must publish under: whether an invite exists (then the review is final), the image
    // fingerprints, gallery list and starting marks it was created with.
    const row = await env.DB.prepare('SELECT manifest, starting, identities, checksums, (SELECT count(*) FROM invites WHERE review_id = reviews.id) AS invites FROM reviews WHERE id = ?').bind(r.id).first();
    if (!row) return json({ error: 'not-found' }, 404);
    return new Response('{"committed":' + (row.invites > 0) + ',"identities":' + (row.identities || '{}') + ',"checksums":' + (row.checksums || '{}') +
                        ',"manifest":' + row.manifest + ',"marks":' + (row.starting || '[]') + '}',
                        { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
  }
  if (action === 'starting' && req.method === 'GET') {
    const row = await env.DB.prepare('SELECT starting FROM reviews WHERE id = ?').bind(r.id).first();
    if (!row) return json({ error: 'not-found' }, 404);
    return new Response('{"marks":' + (row.starting || '[]') + '}', { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
  }
  if (req.method !== 'POST') return json({ error: 'not-found' }, 404);
  const b = await req.json().catch(() => ({}));
  if (action === 'delete-files') {
    if (!env.REVIEW_IMAGES) return json({ error: 'delete-files-unavailable' }, 501);
    // Close the image-write path before clearing the shards. The marks and their recovery journal stay live.
    const fence = await env.DB.prepare(`UPDATE reviews SET status = 'closed', expires_at = min(expires_at, ?)
      WHERE id = ? AND (expires_at <= ? OR NOT EXISTS
        (SELECT 1 FROM invites WHERE review_id = ? AND revoked = 0 AND expires_at > ?))
      RETURNING id`).bind(now, r.id, now, r.id, now).first();
    if (!fence) return json({ error: 'review-still-open' }, 409);
    try {
      await clearImageShards(env, r.id);
      await env.DB.batch([
        env.DB.prepare('DELETE FROM hosted_uploads WHERE review_id = ?').bind(r.id),
        env.DB.prepare('DELETE FROM hosted_manifest_files WHERE review_id = ?').bind(r.id),
        env.DB.prepare("UPDATE reviews SET manifest = '{}', starting = NULL, identities = NULL, checksums = NULL WHERE id = ?").bind(r.id),
      ]);
    } catch {
      return json({ error: 'retry-delete-files' }, 503);
    }
    return json({ filesDeleted: true });
  }
  if (action === 'invites') {
    if (r.status === 'closed') return json({ error: 'files-deleted' }, 410);
    // Braid makes the invite's token and id and sends only the token's hash, so a retry after a lost reply is the same
    // invite (never a second one), and the token never needs to come back from the service.
    if (!['view', 'pick'].includes(b.role) || typeof b.label !== 'string' || !b.label || b.label.length > 80 || !ID.test(b.inviteId || '') || !/^[0-9a-f]{64}$/.test(b.tokenHash || '')) return json({ error: 'bad-request' }, 400);
    const expiresAt = Math.min(Number.isInteger(b.expiresAt) ? b.expiresAt : r.expires_at, r.expires_at);
    const insert = env.DB.prepare('INSERT OR IGNORE INTO invites (id, review_id, token_hash, role, label, expires_at) VALUES (?, ?, ?, ?, ?, ?)').bind(b.inviteId, r.id, b.tokenHash, b.role, b.label, expiresAt);
    if (env.REVIEW_IMAGES) {
      try {
        await env.DB.batch([hostedLiveGuard(env, r.id), insert, env.DB.prepare(`UPDATE hosted_lifecycle SET committed = 1,
          due_at = (SELECT max(purge_after, expires_at) FROM reviews WHERE id = ?)
          WHERE review_id = ? AND committed = 0 AND EXISTS (SELECT 1 FROM invites WHERE review_id = ?)`)
          .bind(r.id, r.id, r.id)]);
      } catch (error) {
        if (await hostedIsRetired(env, r.id)) return retiredResponse();
        throw error;
      }
    } else await insert.run();
    const inv = await env.DB.prepare('SELECT review_id, token_hash, expires_at FROM invites WHERE id = ?').bind(b.inviteId).first();
    if (!inv || inv.review_id !== r.id || inv.token_hash !== b.tokenHash) return json({ error: 'exists' }, 409);
    return json({ inviteId: b.inviteId, expiresAt: inv.expires_at });
  }

  if (action === 'restore-link') {
    if (!ID.test(b.inviteId || '')) return json({ error: 'bad-request' }, 400);
    // Restore only the original invite. The same SQL statement checks the delete fence and its deadline.
    const lifecycle = env.REVIEW_IMAGES
      ? "AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = invites.review_id AND state = 'live' AND committed = 1)"
      : "";
    const invite = await env.DB.prepare(`UPDATE invites SET revoked = 0
      WHERE id = ? AND review_id = ? AND expires_at > ?
      AND EXISTS (SELECT 1 FROM reviews WHERE id = invites.review_id AND status = 'open' AND expires_at > ? AND purge_after > ?)
      ${lifecycle} RETURNING expires_at`).bind(b.inviteId, r.id, now, now, now).first();
    if (!invite) return json({ error: 'link-unavailable' }, 409);
    return json({ restored: true });
  }

  if (action === 'revoke') {
    if (b.all === true) await env.DB.prepare('UPDATE invites SET revoked = 1 WHERE review_id = ?').bind(r.id).run();
    else if (ID.test(b.inviteId || '')) await env.DB.prepare('UPDATE invites SET revoked = 1 WHERE review_id = ? AND id = ?').bind(r.id, b.inviteId).run();
    else return json({ error: 'bad-request' }, 400);
    return json({ ok: true });
  }
  if (action === 'expire') {
    // Closes (or reopens until) the given time for clients; the host keeps access until the purge date.
    if (r.status === 'closed') return json({ error: 'files-deleted' }, 410);
    if (!Number.isInteger(b.expiresAt) || b.expiresAt > r.purge_after) return json({ error: 'bad-request' }, 400);
    await env.DB.prepare('UPDATE reviews SET expires_at = ? WHERE id = ?').bind(b.expiresAt, r.id).run();
    return json({ ok: true, expiresAt: b.expiresAt });
  }
  return json({ error: 'not-found' }, 404);
}

async function writeMark(req, env, s) {
  if (s.role !== 'pick') return json({ error: 'view-only' }, 403);
  const b = await req.json().catch(() => null);
  if (!validMark(b)) return json({ error: 'bad-request' }, 400);
  // The network provider's name only (for example a mobile carrier), never the address.
  return commitMark(env, s.review_id, 'invite:' + s.invite_id, String((req.cf && req.cf.asOrganization) || 'unknown').slice(0, 80), b);
}

// The host (Braid on the photographer's Mac): a per-review key, sent as a bearer token, stored only as a hash.
async function hostReview(req, env, reviewId) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ') || !/^[A-Za-z0-9_-]{8,64}$/.test(reviewId)) return null;
  const r = await env.DB.prepare('SELECT id, title, host_hash, expires_at, purge_after, status, last_client_edit FROM reviews WHERE id = ?').bind(reviewId).first();
  if (!r || Date.now() > r.purge_after || await hostedIsRetired(env, reviewId)) return null;
  return safeEqual(r.host_hash, await sha256(auth.slice(7))) ? r : null;
}

// Select one indexed job. Updating due_at lets other due reviews make progress when this job hits an R2 error.
async function claimHostedSweep(env, now) {
  const claimed = await env.DB.prepare(`WITH
    active AS (SELECT review_id, due_at FROM hosted_lifecycle WHERE state = 'live' AND due_at < ? ORDER BY due_at, review_id LIMIT 1),
    retries AS (SELECT review_id, due_at FROM hosted_lifecycle WHERE state = 'retiring' AND due_at <= ? ORDER BY due_at, review_id LIMIT 1),
    next_job AS (SELECT * FROM active UNION ALL SELECT * FROM retries ORDER BY due_at, review_id LIMIT 1)
    UPDATE hosted_lifecycle SET state = 'retiring', due_at = ?
    WHERE review_id = (SELECT review_id FROM next_job) RETURNING review_id`).bind(now, now, now + SWEEP_RETRY_MS).first();
  return claimed?.review_id;
}

// Release the storage budget only after every shard confirms deletion.
async function clearImageShards(env, id) {
  for (let shard = 0; shard < IMAGE_SHARDS; ++shard) {
    const result = await imageStore(env, id, shard).fetch(new Request(
      `https://review-storage.internal/retire/${id}`, { method: 'POST' }));
    if (result.status !== 204) throw new Error('Review storage could not be cleared');
  }
}

async function sweepHostedReview(env, now) {
  const id = await claimHostedSweep(env, now);
  if (!id) return;
  const cleared = await env.DB.prepare('SELECT 1 AS complete FROM hosted_cleaned_storage WHERE review_id = ?').bind(id).first();
  if (!cleared) {
    await clearImageShards(env, id);
    await env.DB.prepare(`INSERT OR IGNORE INTO hosted_cleaned_storage (review_id)
      SELECT review_id FROM hosted_lifecycle WHERE review_id = ? AND state = 'retiring'`).bind(id).run();
  }
  // Row counts here are bounded independently of the number of photos or client actions in the shoot.
  // Keep invites until all their session rows have gone. No admission path can add data after the fence.
  const tables = ['hosted_uploads', 'hosted_manifest_files', 'marks', 'journal', 'fences'];
  const stmts = tables.map(table => env.DB.prepare(`DELETE FROM ${table} WHERE rowid IN (
    SELECT rowid FROM ${table} WHERE review_id = ? LIMIT ?)`).bind(id, SWEEP_DATA_BATCH));
  stmts.push(env.DB.prepare(`DELETE FROM sessions WHERE rowid IN (
    SELECT s.rowid FROM invites i JOIN sessions s ON s.invite_id = i.id WHERE i.review_id = ? LIMIT ?)`)
    .bind(id, SWEEP_DATA_BATCH), env.DB.prepare(`DELETE FROM invites WHERE rowid IN (
    SELECT i.rowid FROM invites i WHERE i.review_id = ? AND NOT EXISTS (SELECT 1 FROM sessions s WHERE s.invite_id = i.id) LIMIT ?)`)
    .bind(id, SWEEP_DATA_BATCH));
  const dependentTables = [...tables, 'invites'];
  const stillPresent = dependentTables.map(table =>
    `NOT EXISTS (SELECT 1 FROM ${table} WHERE review_id = ?)`).join(' AND ');
  stmts.push(env.DB.prepare(`DELETE FROM reviews WHERE id = ? AND ${stillPresent}`)
    .bind(id, ...dependentTables.map(() => id)), env.DB.prepare(`UPDATE hosted_lifecycle SET state = 'retired', committed = 0, due_at = 0
      WHERE review_id = ? AND state = 'retiring' AND NOT EXISTS (SELECT 1 FROM reviews WHERE id = ?) AND ${stillPresent}`)
    .bind(id, id, ...dependentTables.map(() => id)),
    env.DB.prepare(`DELETE FROM hosted_cleaned_storage WHERE review_id = ? AND
      EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'retired')`).bind(id, id));
  await env.DB.batch(stmts);
}

function metered(env) {
  const m = { rr: 0, rw: 0 };
  const add = r => { if (r && r.meta) { m.rr += r.meta.rows_read || 0; m.rw += r.meta.rows_written || 0; } return r; };
  const wrap = st => ({
    bind: (...a) => wrap(st.bind(...a)),
    first: async () => { const r = add(await st.all()); return (r.results && r.results[0]) || null; },
    all: async () => add(await st.all()),
    run: async () => add(await st.run()),
    raw: st,
  });
  const DB = { prepare: q => wrap(env.DB.prepare(q)), batch: async list => (await env.DB.batch(list.map(x => x.raw))).map(add) };
  return { env: { ...env, DB }, m };
}

export default {
  async scheduled(_event, env) {
    if (env.REVIEW_IMAGES) await sweepHostedReview(env, Date.now());
  },
  async fetch(req, env) {
    if (env.BRAID_METRICS === '1') {
      const t0 = performance.now(), { env: e, m } = metered(env);
      const res = await handle(req, e);
      const h = new Headers(res.headers); h.set('x-braid-metrics', `rr=${m.rr};rw=${m.rw};ms=${(performance.now() - t0).toFixed(1)}`);
      return new Response(res.body, { status: res.status, headers: h });
    }
    return handle(req, env);
  },
};

async function handle(req, env) {
  {
    const url = new URL(req.url);
    const p = url.pathname;
    if (req.method === 'GET' && (p === '/' || p === '/app.js' || p === '/marks.js' || p === '/app.css')) {
      return asset(env, req, url, p === '/' ? '/index.html' : p, { 'Content-Security-Policy': CSP });
    }
    if (p === '/api/session' && req.method === 'POST') {
      if (!sameOrigin(req, url)) return json({ error: 'origin' }, 403);
      const b = await req.json().catch(() => null);
      if (!b || typeof b.token !== 'string' || b.token.length < 20 || b.token.length > 100) return json({ error: 'invalid' }, 403);
      const inv = await env.DB.prepare(
        `SELECT i.id, i.revoked, i.expires_at AS iexp, r.expires_at AS rexp, r.status, r.id AS review_id FROM invites i JOIN reviews r ON r.id = i.review_id WHERE i.token_hash = ?`
      ).bind(await sha256(b.token)).first();
      const now = Date.now();
      if (!inv || inv.revoked || inv.status !== 'open' || now > inv.iexp || now > inv.rexp || await hostedIsRetired(env, inv.review_id)) return json({ error: 'invalid' }, 403);
      const sid = randomToken();
      const insert = env.DB.prepare('INSERT INTO sessions (id_hash, invite_id, created_at) VALUES (?, ?, ?)').bind(await sha256(sid), inv.id, now);
      if (env.REVIEW_IMAGES) {
        try { await env.DB.batch([hostedLiveGuard(env, inv.review_id), insert]); }
        catch (error) {
          if (await hostedIsRetired(env, inv.review_id)) return json({ error: 'invalid' }, 403);
          throw error;
        }
      } else await insert.run();
      const maxAge = Math.max(0, Math.floor((Math.min(inv.iexp, inv.rexp) - now) / 1000));
      return json({ ok: true }, 200, { 'Set-Cookie': `brs=${sid}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}` });
    }
    if (p === '/admin/reviews' && req.method === 'POST') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return createReview(env, await req.json().catch(() => null));
    }
    if (env.REVIEW_IMAGES && p === '/admin/capabilities' && req.method === 'GET') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      const budget = hostedBudget(env);
      if (budget == null) return json({ error: 'storage-unavailable' }, 503);
      const available = await env.DB.prepare(`SELECT s.id FROM hosted_storage s
        LEFT JOIN hosted_lifecycle l ON l.review_id = '' WHERE s.id = 1`).first().catch(() => null);
      if (!available) return json({ error: 'storage-unavailable' }, 503);
      return json({ service: 'braid-review', protocolVersion: 1, storage: 'private-durable-sqlite', deleteOnlineGallery: true, restoreReviewLink: true, galleryViewerVersion: 9, budgetBytes: budget, maxImageBytes: MAX_HOSTED_IMAGE_BYTES });
    }
    const capacityCheck = p.match(/^\/admin\/storage\/check\/([A-Za-z0-9_-]{8,64})$/);
    if (env.REVIEW_IMAGES && ((p === '/admin/storage' && req.method === 'GET') || (capacityCheck && req.method === 'POST'))) {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return hostedCapacity(env, capacityCheck?.[1], req);
    }
    const upload = p.match(/^\/admin\/assets\/([A-Za-z0-9_-]{8,64})\/(t|p)\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (env.REVIEW_IMAGES && upload && req.method === 'PUT') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return uploadHostedImage(req, env, upload[1], upload[2], upload[3]);
    }
    // Grid tiles for Braid (host key): thumbnails in its conflict list.
    const hostImg = p.match(/^\/host\/([A-Za-z0-9_-]{8,64})\/img\/t\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (hostImg && req.method === 'GET') {
      const r = await hostReview(req, env, hostImg[1]);
      if (!r) return json({ error: 'host-auth' }, 401);
      // By gallery key: the tile's file name comes from the manifest (files are named by content).
      const row = await env.DB.prepare('SELECT manifest FROM reviews WHERE id = ?').bind(r.id).first();
      if (!row) return json({ error: 'not-found' }, 404);
      const img = (JSON.parse(row.manifest).images || []).find(i => i.key === hostImg[2]);
      if (!img) return json({ error: 'not-found' }, 404);
      return reviewImage(env, req, url, r.id, 't', img.thumb);
    }
    const host = p.match(/^\/host\/([A-Za-z0-9_-]{8,64})\/(marks|mark|settle|status|invites|revoke|restore-link|expire|starting|committed|delete-files)$/);
    if (host) {
      const r = await hostReview(req, env, host[1]);
      if (!r) return json({ error: 'host-auth' }, 401);
      // Braid's idle read: changed marks plus the last client edit (already on the review row it authenticated with).
      if (host[2] === 'marks' && req.method === 'GET') return json({ ...(await marksSince(env, r.id, url)), lastClientEditAt: r.last_client_edit || null });
      if ((host[2] === 'starting' || host[2] === 'committed') && req.method === 'GET') return hostManage(req, env, r, host[2]);
      if ((host[2] === 'mark' || host[2] === 'settle') && req.method === 'POST') {
        const b = await req.json().catch(() => null);
        if (!validMark(b)) return json({ error: 'bad-request' }, 400);
        return host[2] === 'mark' ? commitMark(env, r.id, 'host', null, b) : settleMark(env, r.id, 'host', b);
      }
      return hostManage(req, env, r, host[2]);
    }
    const s = await sessionFor(req, env);
    if (!s) return json({ error: 'signin' }, 401);
    if (s.denied) return json({ error: s.denied }, 403);
    if (p === '/api/review' && req.method === 'GET') {
      // The stored gallery list goes out as it is (no parse and re-serialise on every open); marks come from /api/marks.
      const m = await env.DB.prepare('SELECT manifest FROM reviews WHERE id = ?').bind(s.review_id).first();
      if (!m) return json({ error: 'expired' }, 403);
      const meta = JSON.stringify({ role: s.role, label: s.label, title: s.title, version: s.version, expiresAt: Math.min(s.iexp, s.rexp) });
      return new Response('{"manifest":' + m.manifest + ',' + meta.slice(1), { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
    }
    if (p === '/api/marks' && req.method === 'GET') return json(await marksSince(env, s.review_id, url));
    if (p === '/api/mark' && req.method === 'POST') {
      if (!sameOrigin(req, url)) return json({ error: 'origin' }, 403);
      return writeMark(req, env, s);
    }
    // Images of this session's review only: grid tiles (t) and viewer images (p).
    const im = p.match(/^\/img\/(p|t)\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (req.method === 'GET' && im) return reviewImage(env, req, url, s.review_id, im[1], im[2], { 'Cache-Control': 'private, max-age=86400, immutable' });
    return json({ error: 'not-found' }, 404);
  }
}
