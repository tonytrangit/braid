import {
  hexBytes, json, MAX_HOSTED_IMAGE_BYTES,
  reserveHostedImage, settleHostedImage, storageReviewState,
} from './worker.js';

const SHARD_SAFE_BYTES = 900_000_000;
const MAX_CONCURRENT_UPLOAD_BODIES = 4;
const OBJECT_PATH = /^\/objects\/([A-Za-z0-9_-]{8,64})\/(t|p)\/([A-Za-z0-9_-]{8,64})$/;
const RETIRE_PATH = /^\/retire\/([A-Za-z0-9_-]{8,64})$/;
const DIGEST = /^[0-9a-f]{64}$/;

// Read one bounded image into memory. Reading and hashing finish before the reservation or write.
async function readImage(request, size) {
  const reader = request.body?.getReader();
  if (!reader) return null;
  const data = new Uint8Array(size);
  let offset = 0;
  let ended = false;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) { ended = true; break; }
      if (offset + value.length > size) return null;
      data.set(value, offset);
      offset += value.length;
    }
  } finally {
    if (!ended) await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  if (offset !== size || data[0] !== 255 || data[1] !== 216 || data[size - 2] !== 255 || data[size - 1] !== 217) return null;
  return data;
}

// A classic fetch-only Durable Object. The namespace is private to the Worker.
export class ReviewImages {
  constructor(ctx, env) {
    this.storage = ctx.storage;
    this.env = env;
    this.queue = Promise.resolve();
    this.uploadBodies = 0;
  }

  serialize(work) {
    const operation = this.queue.then(work);
    this.queue = operation.catch(() => {});
    return operation;
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    const retirement = path.match(RETIRE_PATH);
    if (request.method === 'POST' && retirement) {
      return this.serialize(async () => {
        const state = await storageReviewState(this.env, retirement[1]);
        if (state !== 'retiring' && state !== 'retired' && state !== 'closed') return json({ error: 'review-still-live' }, 409);
        // deleteAll deallocates the whole shard including SQLite pages. The permanent D1 fence guards future writes.
        await this.storage.deleteAll();
        await this.storage.sync();
        return new Response(null, { status: 204 });
      });
    }
    const object = path.match(OBJECT_PATH);
    if (!object) return json({ error: 'not-found' }, 404);
    const [, id, kind, name] = object;
    const digest = request.headers.get('X-Braid-SHA256') || '';
    if (!DIGEST.test(digest)) return json({ error: 'bad-content-name' }, 400);
    if (request.method === 'GET') return this.read(id, kind, name, digest);
    if (request.method === 'PUT') return this.upload(request, id, kind, name, digest);
    return json({ error: 'not-found' }, 404);
  }

  async read(id, kind, name, digest) {
    // Do not recreate an empty shard after retirement or when a published image has gone missing.
    if (await storageReviewState(this.env, id) !== 'live') return json({ error: 'not-found' }, 404);
    if (!this.storage.sql.databaseSize) return json({ error: 'not-found' }, 404);
    const row = this.storage.sql.exec('SELECT digest, body FROM images WHERE kind = ? AND name = ?', kind, name).toArray()[0];
    if (!row) return json({ error: 'not-found' }, 404);
    // Fail closed even if stored checksum metadata survived damage to the bytes.
    if (row.digest !== digest || hexBytes(await crypto.subtle.digest('SHA-256', row.body)) !== digest) {
      return json({ error: 'image-checksum-mismatch' }, 502);
    }
    return new Response(row.body, { headers: {
      'Cache-Control': 'private, no-store', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff',
      'Content-Type': 'image/jpeg', 'Content-Length': String(row.body.byteLength),
    } });
  }

  async upload(request, id, kind, name, digest) {
    const size = Number(request.headers.get('Content-Length'));
    if (!Number.isSafeInteger(size) || size < 4 || size > MAX_HOSTED_IMAGE_BYTES) return json({ error: 'bad-image' }, 400);
    if (this.uploadBodies >= MAX_CONCURRENT_UPLOAD_BODIES) return json({ error: 'retry-upload' }, 503);
    this.uploadBodies++;
    try {
      const data = await readImage(request, size).catch(() => null);
      if (!data) return json({ error: 'bad-image' }, 400);
      if (hexBytes(await crypto.subtle.digest('SHA-256', data)) !== digest) return json({ error: 'checksum-mismatch' }, 422);
      const repair = request.headers.get('X-Braid-Repair') === '1';
      return await this.serialize(async () => {
        const denied = await reserveHostedImage(this.env, id, kind, name, digest, size, repair);
        if (denied) return denied;
        // This D1 primary read comes after the body and any preceding deleteAll. If retirement commits afterward,
        // the scheduled delete must still pass through this same shard queue before it can release reservations.
        if (await storageReviewState(this.env, id) !== 'live') return json({ error: 'review-retired' }, 410);
        const result = this.store(kind, name, digest, data, repair);
        if (result) return result;
        await this.storage.sync();
        return await settleHostedImage(this.env, id, kind, name);
      });
    } finally {
      this.uploadBodies--;
    }
  }

  store(kind, name, digest, data, repair) {
    const sql = this.storage.sql;
    sql.exec(`CREATE TABLE IF NOT EXISTS images (
      kind TEXT NOT NULL, name TEXT NOT NULL, digest TEXT NOT NULL, body BLOB NOT NULL,
      PRIMARY KEY (kind, name)
    ) WITHOUT ROWID`);
    const old = sql.exec('SELECT digest, length(body) AS size FROM images WHERE kind = ? AND name = ?', kind, name).toArray()[0];
    if (old && !repair) {
      return old.digest === digest && old.size === data.byteLength ? null : json({ error: 'content-conflict' }, 409);
    }
    if (!old && sql.databaseSize + data.byteLength + 65_536 > SHARD_SAFE_BYTES) return json({ error: 'storage-unavailable' }, 503);
    if (repair && old) {
      sql.exec('UPDATE images SET digest = ?, body = ? WHERE kind = ? AND name = ?', digest, data.buffer, kind, name);
    } else {
      sql.exec('INSERT INTO images (kind, name, digest, body) VALUES (?, ?, ?, ?)', kind, name, digest, data.buffer);
    }
    return null;
  }
}
