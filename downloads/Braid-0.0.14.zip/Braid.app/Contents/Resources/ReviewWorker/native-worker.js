import worker from "./worker.js";
import { assets } from "./gallery-assets.js";
export { ReviewImages } from "./review-images.js";
export default {
  fetch(request, env, context) {
    return worker.fetch(request, Object.assign(Object.create(env), { ASSETS: assets }), context);
  },
  scheduled(controller, env, context) {
    return worker.scheduled(controller, env, context);
  },
};
