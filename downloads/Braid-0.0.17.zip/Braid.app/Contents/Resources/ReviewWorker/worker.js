// Braid review service. Every request (pages, data and images) runs here first: nothing is served
// without a valid, unrevoked, unexpired invite session. Marks change only against the revision the reviewer saw.
// Three kinds of caller:
//   admin  - Braid on the photographer's Mac, with the installation's admin key: creates reviews.
//   host   - Braid with one review's host key: reads and updates marks, manages invites, expires the review. Keeps
//            working after the review closes to clients, until its purge date, so picks can still be synced back.
//   client - a browser with an invite session: sees only that review's gallery, images and marks.
const enc = new TextEncoder();
const PRIVATE = { 'Cache-Control': 'private, no-store', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff' };
const CSP = "default-src 'self'; img-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";

async function sha256(s) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(s));
  return hexBytes(d);
}
export function hexBytes(bytes) {
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function randomToken(bytes = 32) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a);
  return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function json(body, status = 200, extra = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...PRIVATE, ...extra } });
}
function cookie(req, name) {
  const m = (req.headers.get('Cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? m[1] : null;
}
function sameOrigin(req, url) { return req.headers.get('Origin') === url.origin; }
async function asset(env, req, url, path, extraHeaders = {}) {
  const r = await env.ASSETS.fetch(new Request(new URL(path, url), { headers: req.headers }));
  const h = new Headers(r.headers);
  for (const [k, v] of Object.entries({ ...PRIVATE, ...extraHeaders })) h.set(k, v);
  return new Response(r.body, { status: r.status, headers: h });
}

async function sessionFor(req, env) {
  const sid = cookie(req, 'brs');
  if (!sid) return null;
  // Deadlines are decided on the database clock in this same read: a Worker clock behind the database would keep
  // serving a gallery the database has already expired. Both deadlines are inclusive (past means strictly before).
  const row = await env.DB.prepare(
    `SELECT s.invite_id, i.role, i.label, i.revoked, i.expires_at AS iexp, r.id AS review_id, r.title, r.expires_at AS rexp, r.status, r.version,
       i.expires_at < ${DB_NOW} AS i_gone, r.expires_at < ${DB_NOW} AS r_gone
       FROM sessions s JOIN invites i ON i.id = s.invite_id JOIN reviews r ON r.id = i.review_id WHERE s.id_hash = ?`
  ).bind(await sha256(sid)).first();
  if (!row) return null;
  if (row.revoked) return { denied: 'revoked' };
  if (row.status !== 'open') return { denied: 'closed' };
  if (row.i_gone || row.r_gone || await hostedIsRetired(env, row.review_id)) return { denied: 'expired' };
  return row;
}

// Marks changed since a cursor, in pages. Every committed change gives the mark the review's next sequence number (in
// the same transaction), so a reader that keeps the last cursor it saw never misses or double-counts a change, and an
// idle poll reads no mark rows at all. since=-1 (or absent) reads from the beginning.
async function marksSince(env, reviewId, url) {
  const since = Math.max(-1, parseInt(url.searchParams.get('since') || '-1', 10) || -1);
  const limit = Math.min(2000, Math.max(1, parseInt(url.searchParams.get('limit') || '2000', 10) || 2000));
  const { results } = await env.DB.prepare('SELECT variant_key AS k, field AS f, value AS v, rev AS r, seq AS s FROM marks WHERE review_id = ? AND seq > ? ORDER BY seq LIMIT ?')
    .bind(reviewId, since, limit + 1).all();
  const more = results.length > limit;
  const page = more ? results.slice(0, limit) : results;
  return { reviewId, marks: page, cursor: page.length ? page[page.length - 1].s : since, more };
}

function validMark(b) {
  if (!b || typeof b.key !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(b.key)) return false;
  if (!['rating', 'color'].includes(b.field)) return false;
  const max = b.field === 'rating' ? 5 : 7;
  if (!Number.isInteger(b.value) || b.value < 0 || b.value > max) return false;
  return Number.isInteger(b.baseRev) && typeof b.requestId === 'string' && /^[A-Za-z0-9_-]{16,64}$/.test(b.requestId);
}

// The database's own clock in Unix milliseconds. A queued batch can run after an expiry that the Worker's earlier
// Date.now() missed. ROUND before CAST: a plain CAST can undercount by 1 ms.
const DB_NOW = "CAST(ROUND((julianday('now') - 2440587.5) * 86400000) AS INTEGER)";
// A content-only Worker upgrade keeps the existing database, which may predate hosted_lifecycle: create the table,
// its index and schema.sql's backfill lazily in one idempotent batch before anything reads it. One promise per
// database, so every later request in this isolate reuses it; a failure changes nothing and is retried next request.
const lifecycleReady = new WeakMap();
function ensureLifecycle(env) {
  let ready = lifecycleReady.get(env.DB);
  if (!ready) {
    ready = env.DB.batch([
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS hosted_lifecycle (
        review_id TEXT PRIMARY KEY,
        state TEXT NOT NULL DEFAULT 'live' CHECK (state IN ('live','retiring','retired')),
        committed INTEGER NOT NULL DEFAULT 0 CHECK (committed IN (0,1)),
        due_at INTEGER NOT NULL)`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS hosted_lifecycle_due ON hosted_lifecycle (state, due_at, review_id)'),
      env.DB.prepare('CREATE TABLE IF NOT EXISTS hosted_cleaned_storage (review_id TEXT PRIMARY KEY)'),
      env.DB.prepare('CREATE TABLE IF NOT EXISTS sweep_claim (review_id TEXT PRIMARY KEY, token TEXT NOT NULL, claimed_at INTEGER NOT NULL)'),
      // A sweep records that it has begun sending shard deletes. Such a gallery can never return to live.
      env.DB.prepare('CREATE TABLE IF NOT EXISTS sweep_deleting (review_id TEXT PRIMARY KEY)'),
      env.DB.prepare('CREATE TABLE IF NOT EXISTS delete_claim (review_id TEXT PRIMARY KEY, token TEXT NOT NULL, claimed_at INTEGER NOT NULL)'),
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS cleanup_retry (
        review_id TEXT PRIMARY KEY, next_try_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0)`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS cleanup_retry_due ON cleanup_retry (next_try_at, review_id)'),
      env.DB.prepare(`INSERT OR IGNORE INTO hosted_lifecycle (review_id, committed, due_at)
        SELECT id, EXISTS (SELECT 1 FROM invites WHERE review_id = r.id),
          CASE WHEN EXISTS (SELECT 1 FROM invites WHERE review_id = r.id) THEN max(purge_after, expires_at)
               ELSE max(created_at, CAST(strftime('%s','now') AS INTEGER) * 1000) + 604800000 END
          FROM reviews r`),
      env.DB.prepare(`INSERT OR IGNORE INTO hosted_lifecycle (review_id, due_at)
        SELECT DISTINCT review_id, CAST(strftime('%s','now') AS INTEGER) * 1000 + 604800000 FROM hosted_uploads`),
      // First run after the upgrade that made closure enqueue its retry atomically: a gallery the previous build left
      // closed with files but no retry row would otherwise never be cleared. The marker keeps this to one run per database.
      env.DB.prepare('CREATE TABLE IF NOT EXISTS cleanup_backfill (done INTEGER PRIMARY KEY)'),
      env.DB.prepare(`INSERT OR IGNORE INTO cleanup_retry (review_id, next_try_at, attempts)
        SELECT r.id, ${DB_NOW}, 0 FROM reviews r JOIN hosted_lifecycle l ON l.review_id = r.id
        WHERE r.status = 'closed' AND l.state = 'live' AND NOT ${filesCleared('r')}
        AND NOT EXISTS (SELECT 1 FROM cleanup_backfill)`),
      // The previous build had no deletion mark: fence every gallery its sweep had already begun, so the upgrade can
      // never release one whose shards may already be gone. Once-only, with the same marker.
      env.DB.prepare(`INSERT OR IGNORE INTO sweep_deleting (review_id)
        SELECT review_id FROM hosted_lifecycle WHERE state = 'retiring'
        AND NOT EXISTS (SELECT 1 FROM cleanup_backfill)`),
      env.DB.prepare('INSERT OR IGNORE INTO cleanup_backfill (done) VALUES (1)'),
    ]).catch(error => { lifecycleReady.delete(env.DB); throw error; });
    lifecycleReady.set(env.DB, ready);
  }
  return ready;
}
// The access checks sessionFor makes, against the database clock. Used inside a client write's transaction and once
// more after it, so a revoke, close or expiry that has committed stops every later client save.
async function accessGone(env, reviewId, inviteId) {
  const row = await env.DB.prepare(
    `SELECT i.revoked, r.status, i.expires_at < ${DB_NOW} AS iexp, r.expires_at < ${DB_NOW} AS rexp
       FROM invites i JOIN reviews r ON r.id = i.review_id WHERE i.id = ? AND r.id = ?`
  ).bind(inviteId, reviewId).first();
  if (!row) return 'expired';
  if (row.revoked) return 'revoked';
  if (row.status !== 'open') return 'closed';
  if (row.iexp || row.rexp || await hostedIsRetired(env, reviewId)) return 'expired';
  return null;
}

// Cover + link preview. The tables are created lazily, in one idempotent batch, by the host's publish only: a
// content-only Worker upgrade keeps a pre-preview database, and every read (and the cron) tolerates their absence.
// `source` records where a cover came from, so a publish's auto cover can replace only a legacy/auto seed and never
// a photographer's choice. A row from before the column was known was already chosen: it defaults to photographer.
const previewReady = new WeakMap();
function ensurePreviewTables(env) {
  let ready = previewReady.get(env.DB);
  if (!ready) {
    ready = env.DB.batch([
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS review_cover (
        review_id TEXT PRIMARY KEY, image_key TEXT NOT NULL, rev INTEGER NOT NULL DEFAULT 1,
        source TEXT NOT NULL DEFAULT 'photographer')`),
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS review_preview (
        preview_id TEXT PRIMARY KEY, review_id TEXT NOT NULL, invite_id TEXT NOT NULL,
        title TEXT NOT NULL, line TEXT NOT NULL, created_at INTEGER NOT NULL, rev INTEGER NOT NULL DEFAULT 1)`),
      env.DB.prepare('CREATE UNIQUE INDEX IF NOT EXISTS review_preview_invite ON review_preview (invite_id)'),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS review_preview_review ON review_preview (review_id)'),
    ]).then(async () => {
      const columns = (await env.DB.prepare('PRAGMA table_info(review_cover)').all()).results;
      if (!columns.some(column => column.name === 'source')) {
        await env.DB.prepare("ALTER TABLE review_cover ADD COLUMN source TEXT NOT NULL DEFAULT 'photographer'").run()
          .catch(error => { if (!/duplicate column/i.test(String((error && error.message) || error))) throw error; });
      }
    }).catch(error => { previewReady.delete(env.DB); throw error; });
    previewReady.set(env.DB, ready);
  }
  return ready;
}
function missingTable(error) { return /no such table/i.test(String((error && error.message) || error)); }
// `rev` is the preview's own title revision; the cover has its own.
const CARD_SHAPE = row => ({ previewId: row.preview_id, title: row.title, line: row.line,
  imageKey: row.image_key || null, rev: row.rev });
async function reviewCover(env, reviewId) {
  try {
    const row = await env.DB.prepare('SELECT image_key, rev FROM review_cover WHERE review_id = ?').bind(reviewId).first();
    return row ? { imageKey: row.image_key, rev: row.rev } : null;
  } catch (error) { if (missingTable(error)) return null; throw error; }
}
// A gallery shared before the cover feature has no cover and no preview: seed its first photo once, so Photographer
// mode and the Cover photo tick work on the old link after a Worker update, with no re-share. A gallery whose preview
// is published is already on the cover path, and Braid's own verification read of a new share skips the seed.
// A failed seed is not fatal: the gallery still opens, without a cover.
async function seedLegacyCover(env, reviewId) {
  try {
    await ensurePreviewTables(env);
    await env.DB.prepare(`INSERT OR IGNORE INTO review_cover (review_id, image_key, rev, source)
      SELECT ?, json_extract(value, '$.key'), 1, 'seed'
      FROM json_each((SELECT manifest FROM reviews WHERE id = ?), '$.images')
      WHERE NOT EXISTS (SELECT 1 FROM review_preview WHERE review_id = ?) LIMIT 1`)
      .bind(reviewId, reviewId, reviewId).run();
    return await reviewCover(env, reviewId);
  } catch { return null; }
}
// The host's Share card, scoped to this review's own invite.
async function hostPreviewCard(env, reviewId, inviteId) {
  try {
    return await env.DB.prepare(`SELECT p.preview_id, p.title, p.line, p.rev, c.image_key
      FROM review_preview p JOIN invites i ON i.id = p.invite_id AND i.review_id = p.review_id
      LEFT JOIN review_cover c ON c.review_id = p.review_id
      WHERE p.review_id = ? AND p.invite_id = ?`).bind(reviewId, inviteId).first();
  } catch (error) { if (missingTable(error)) return null; throw error; }
}
// ONE live read for the public card: its invite, the same review, the cover and the manifest entry, with every
// liveness condition on the database clock (revoke, invite expiry, review expiry/close, purge, hosted storage).
async function publicPreviewCard(env, previewId) {
  if (!/^[A-Za-z0-9_-]{22}$/.test(previewId)) return null;
  const hosted = env.REVIEW_IMAGES
    ? `AND EXISTS (SELECT 1 FROM hosted_lifecycle l WHERE l.review_id = p.review_id
        AND l.state = 'live' AND l.committed = 1)` : '';
  try {
    return await env.DB.prepare(`SELECT p.preview_id, p.title, p.line, p.review_id, c.image_key, c.rev,
      json_extract(img.value, '$.thumb') AS thumb, json_extract(img.value, '$.preview') AS preview,
      (SELECT u.bytes FROM hosted_uploads u WHERE u.review_id = p.review_id AND u.kind = 'p'
        AND u.name = json_extract(img.value, '$.preview')) AS p_bytes
      FROM review_preview p
      JOIN invites i ON i.id = p.invite_id AND i.review_id = p.review_id
      JOIN reviews r ON r.id = p.review_id
      JOIN review_cover c ON c.review_id = p.review_id
      JOIN json_each(r.manifest, '$.images') img ON json_extract(img.value, '$.key') = c.image_key
      WHERE p.preview_id = ? AND i.revoked = 0 AND i.expires_at >= ${DB_NOW}
      AND r.status = 'open' AND r.expires_at >= ${DB_NOW} AND r.purge_after >= ${DB_NOW} ${hosted}`)
      .bind(previewId).first();
  } catch (error) { if (missingTable(error)) return null; throw error; }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
// The bundled page with card tags, so a pasted link shows the title, line and cover. Values are escaped for an
// attribute context; HTMLRewriter finds the head without depending on the page's exact markup.
async function withOgTags(html, card, origin) {
  const image = `${origin}/p/${card.preview_id}/cover.jpg?v=${card.rev}`;
  const tags = [
    ['og:title', card.title], ['og:description', card.line], ['og:image', image],
  ].map(([property, content]) => `<meta property="${property}" content="${escapeHtml(content)}">`).join('')
    + '<meta property="og:type" content="website"><meta name="twitter:card" content="summary_large_image">';
  const rewritten = new HTMLRewriter().on('head', {
    element(element) { element.append(tags, { html: true }); },
  }).transform(new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } }));
  return await rewritten.text();
}

// One change by one sender (a reviewer's invite, or the host), revision-checked.
// - The history entry is the operation: the update applies only that entry's value, and only from its base revision,
//   and both are committed in one transaction (one D1 batch) or not at all.
// - A client write's history entry exists only while its invite is still live (checked in that same transaction).
// - Request ids are scoped to the review and the sender. A retry gets the exact receipt of the commit (its value and
//   the revision it created), never the current state; reusing an id for different content is refused.
export async function commitMark(env, reviewId, actor, network, b) {
  const op = 'review_id = ? AND actor = ? AND request_id = ?';
  const receipt = async () => {
    const r = await env.DB.prepare(`SELECT variant_key, field, new_value, base_rev, new_rev FROM journal WHERE ${op}`)
      .bind(reviewId, actor, b.requestId).first();
    if (!r) return null;
    if (r.variant_key !== b.key || r.field !== b.field || r.new_value !== b.value || r.base_rev !== b.baseRev) {
      return json({ error: 'request-reused' }, 422);
    }
    return json({ ok: true, value: r.new_value, rev: r.new_rev, requestId: b.requestId });
  };
  const invite = actor.startsWith('invite:') ? actor.slice(7) : null;
  try {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    const earlier = await receipt();
    if (earlier) return earlier;
    const where = 'review_id = ? AND variant_key = ? AND field = ?';
    const mine = 'j.review_id = marks.review_id AND j.variant_key = marks.variant_key AND j.field = marks.field AND j.actor = ? AND j.request_id = ?';
    const at = Date.now();
    // The live-invite condition sits on the statement every later statement depends on, so a revoke, close or expiry
    // committed before this batch leaves no history entry, no mark change and no last edit.
    const fence = invite ? ` AND EXISTS (SELECT 1 FROM invites i JOIN reviews r ON r.id = i.review_id
        WHERE i.id = ? AND r.id = ? AND i.revoked = 0 AND r.status = 'open'
        AND i.expires_at >= ${DB_NOW} AND r.expires_at >= ${DB_NOW})` : '';
    // A review update also needs a history entry for exactly this content AND the mark still at its base revision with
    // a different value: a delayed duplicate (its mark has moved on) or a changed-payload reuse of the same id (the
    // earlier entry has another value/base revision) updates neither mark_seq nor last_client_edit.
    const mineInsert = `AND EXISTS (SELECT 1 FROM journal WHERE ${op} AND variant_key = ? AND field = ? AND base_rev = ? AND new_value = ?)
      AND EXISTS (SELECT 1 FROM marks m WHERE m.review_id = ? AND m.variant_key = ? AND m.field = ? AND m.rev = ? AND m.value <> ?)`;
    const stmts = [
      env.DB.prepare(`INSERT INTO journal (request_id, review_id, variant_key, field, old_value, new_value, base_rev, new_rev, actor, at, network)
                      SELECT ?, review_id, variant_key, field, value, ?, rev, rev + 1, ?, ?, ? FROM marks WHERE ${where} AND rev = ? AND value <> ?
                      AND NOT EXISTS (SELECT 1 FROM fences f WHERE f.review_id = ? AND f.actor = ? AND f.request_id = ?)${fence}`)
        .bind(b.requestId, b.value, actor, at, network, reviewId, b.key, b.field, b.baseRev, b.value, reviewId, actor, b.requestId,
          ...(invite ? [invite, reviewId] : [])),
      // Before the mark update, so on a genuine commit the mark is still at its base revision.
      env.DB.prepare(`UPDATE reviews SET mark_seq = mark_seq + 1 WHERE id = ? ${mineInsert}`)
        .bind(reviewId, reviewId, actor, b.requestId, b.key, b.field, b.baseRev, b.value, reviewId, b.key, b.field, b.baseRev, b.value),
    ];
    // When a client last changed a mark ("last online edit" in Braid), kept with the change itself so Braid reads it
    // with its ordinary incremental read instead of scanning the history.
    if (actor.startsWith('invite:')) stmts.push(env.DB.prepare(`UPDATE reviews SET last_client_edit = ? WHERE id = ? ${mineInsert}`)
      .bind(at, reviewId, reviewId, actor, b.requestId, b.key, b.field, b.baseRev, b.value, reviewId, b.key, b.field, b.baseRev, b.value));
    stmts.push(env.DB.prepare(`UPDATE marks SET value = (SELECT j.new_value FROM journal j WHERE ${mine}), rev = rev + 1, seq = (SELECT mark_seq FROM reviews WHERE id = ?)
                      WHERE ${where} AND rev = (SELECT j.base_rev FROM journal j WHERE ${mine})`)
      .bind(actor, b.requestId, reviewId, reviewId, b.key, b.field, actor, b.requestId));
    if (env.REVIEW_IMAGES) stmts.unshift(hostedLiveGuard(env, reviewId));
    await env.DB.batch(stmts);
  } catch (e) {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    // For example a concurrent retry of the same request committed first (its history entry already exists).
    try { const r = await receipt(); if (r) return r; } catch (_) {}
    return json({ error: 'not-saved' }, 503);
  }
  try {
    const r = await receipt();
    if (r) return r;
    const fenced = await env.DB.prepare('SELECT 1 AS x FROM fences WHERE review_id = ? AND actor = ? AND request_id = ?').bind(reviewId, actor, b.requestId).first();
    if (fenced) return json({ error: 'fenced' }, 410);
    if (invite) {
      const gone = await accessGone(env, reviewId, invite);
      if (gone) return json({ error: 'error', closed: gone }, 403);
    }
    const cur = await env.DB.prepare('SELECT value, rev FROM marks WHERE review_id = ? AND variant_key = ? AND field = ?').bind(reviewId, b.key, b.field).first();
    if (!cur) return json({ error: 'unknown-image' }, 404);
    if (cur.rev === b.baseRev && cur.value === b.value) return json({ ok: true, value: cur.value, rev: cur.rev, noop: true });
    // A live invite's write rejected with the mark still at its base revision can only be the SQL access fence
    // (link since restored): the review is closed, not a conflict with an unchanged revision.
    if (invite && cur.rev === b.baseRev) return json({ error: 'error', closed: 'closed' }, 403);
    return json({ conflict: true, value: cur.value, rev: cur.rev }, 409);
  } catch (e) {
    return json({ error: 'not-saved' }, 503);
  }
}

// Recovery for a request whose reply was lost: returns its committed receipt, or (if it never committed) fences the
// request id first, atomically, so a delayed delivery of the abandoned request can't commit afterwards.
async function settleMark(env, reviewId, actor, b) {
  const op = 'review_id = ? AND actor = ? AND request_id = ?';
  try {
    const insert = env.DB.prepare(`INSERT OR IGNORE INTO fences (review_id, actor, request_id, at) SELECT ?, ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM journal WHERE ${op})`)
      .bind(reviewId, actor, b.requestId, Date.now(), reviewId, actor, b.requestId);
    if (env.REVIEW_IMAGES) await env.DB.batch([hostedLiveGuard(env, reviewId), insert]);
    else await insert.run();
    const r = await env.DB.prepare(`SELECT variant_key, field, new_value, base_rev, new_rev FROM journal WHERE ${op}`).bind(reviewId, actor, b.requestId).first();
    if (r) {
      if (r.variant_key !== b.key || r.field !== b.field || r.new_value !== b.value || r.base_rev !== b.baseRev) return json({ error: 'request-reused' }, 422);
      return json({ committed: true, value: r.new_value, rev: r.new_rev });
    }
    return json({ fenced: true });
  } catch (e) {
    if (await hostedIsRetired(env, reviewId)) return retiredResponse();
    return json({ error: 'not-saved' }, 503);
  }
}

function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i); return x === 0;
}
// One admin key per Mac: each is its own secret, so adding one can never drop another.
const PER_MAC_ADMIN_KEY = /^ADMIN_KEY_HASH_[A-Z0-9]{8,32}$/;
async function isAdmin(req, env) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return false;
  const hash = await sha256(auth.slice(7));
  let matched = false;
  // Compare every configured key, with no early exit that would reveal which one matched. for-in, not
  // Object.entries: the bundled native worker passes bindings through the env object's prototype.
  for (const name in env) {
    if ((name === 'ADMIN_KEY_HASH' || PER_MAC_ADMIN_KEY.test(name)) && typeof env[name] === 'string' && safeEqual(hash, env[name])) matched = true;
  }
  return matched;
}
const ID = /^[A-Za-z0-9_-]{8,64}$/;
const HEX = /^[0-9a-f]{64}$/;
const CONTENT_NAME = /^[A-Za-z0-9_-]{8,47}-[0-9a-f]{16}$/;
// Stay below SQLite's 8 MB limit for the complete row, including its keys and metadata.
export const MAX_HOSTED_IMAGE_BYTES = 7 * 1024 * 1024;
const MAX_HOSTED_BUDGET_BYTES = 4_000_000_000;
const IMAGE_SHARDS = 16;

const DRAFT_LIFETIME_MS = 7 * 86400000;
const SWEEP_RETRY_MS = 60000;
// A tick renews this lease before each shard; a retiring row whose claim is older than one interval is presumed dead.
const SWEEP_LEASE_MS = SWEEP_RETRY_MS;
const SWEEP_DATA_BATCH = 200;
// Galleries closed and cleared per cron tick, and the one-week purge deadline manual Delete clamps to.
const CLOSE_BATCH = 4;
const CLEANUP_TIMEOUT_MS = 20000;
const CLEANUP_MAX_MINUTES = 60;
const PURGE_CLAMP_MS = 7 * 86400000;

function refreshHostedDraft(env, id, now) {
  return env.DB.prepare(`INSERT INTO hosted_lifecycle (review_id, due_at) VALUES (?, ?)
    ON CONFLICT(review_id) DO UPDATE SET due_at = max(hosted_lifecycle.due_at, excluded.due_at)
    WHERE hosted_lifecycle.state = 'live' AND hosted_lifecycle.committed = 0`).bind(id, now + DRAFT_LIFETIME_MS);
}
function hostedLiveGuard(env, id) {
  return env.DB.prepare(`INSERT INTO batch_guard (must_be_null) SELECT NULL WHERE NOT EXISTS (
    SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')`).bind(id);
}
async function hostedIsRetired(env, id) {
  if (!env.REVIEW_IMAGES) return false;
  const row = await env.DB.prepare("SELECT state FROM hosted_lifecycle WHERE review_id = ? AND state <> 'live'").bind(id).first();
  return !!row;
}
function retiredResponse() { return json({ error: 'review-retired' }, 410); }
// A retired review reads as gone (410), not as a bad key (401), so Braid can tell the two apart.
async function hostRefused(env, id) {
  return await hostedIsRetired(env, id) ? retiredResponse() : json({ error: 'host-auth' }, 401);
}
// Shard on the variant key, so a gallery of identical JPEGs still spreads across objects.
export function imageShard(name) {
  let hash = 2166136261;
  for (let i = 0; i < name.length - 17; ++i) hash = Math.imul(hash ^ name.charCodeAt(i), 16777619);
  return (hash >>> 0) % IMAGE_SHARDS;
}
function imageStore(env, id, shard) {
  return env.REVIEW_IMAGES.get(env.REVIEW_IMAGES.idFromName(`${id}/${shard}`));
}


function hostedBudget(env) {
  const bytes = Number(env.BRAID_STORAGE_BUDGET_BYTES);
  return Number.isSafeInteger(bytes) && bytes > 0 && bytes <= MAX_HOSTED_BUDGET_BYTES ? bytes : null;
}

async function hostedCapacity(env, reviewID, req) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  let requestedBytes = 0;
  if (reviewID) {
    if (await hostedIsRetired(env, reviewID)) return retiredResponse();
    const files = await req.json().catch(() => null);
    if (!Array.isArray(files) || files.length > 10000 || !files.every(f => Array.isArray(f) && f.length === 3 &&
        (f[0] === 't' || f[0] === 'p') && typeof f[1] === 'string' && CONTENT_NAME.test(f[1]) &&
        Number.isSafeInteger(f[2]) && f[2] >= 4 && f[2] <= 100000000)) return json({ error: 'bad-request' }, 400);
    const sum = await env.DB.prepare(`SELECT coalesce(sum(bytes), 0) AS required FROM (
      SELECT DISTINCT json_extract(value, '$[0]') AS kind, json_extract(value, '$[1]') AS name,
      json_extract(value, '$[2]') AS bytes FROM json_each(?)
    ) AS proposed WHERE NOT EXISTS (
      SELECT 1 FROM hosted_uploads WHERE review_id = ? AND kind = proposed.kind AND name = proposed.name AND bytes = proposed.bytes
    )`).bind(JSON.stringify(files), reviewID).first();
    requestedBytes = sum.required;
  }
  const usage = await env.DB.prepare('SELECT reserved_bytes FROM hosted_storage WHERE id = 1').first();
  const body = { budgetBytes: budget, reservedBytes: usage.reserved_bytes, availableBytes: Math.max(0, budget - usage.reserved_bytes),
    maxImageBytes: MAX_HOSTED_IMAGE_BYTES, requestedBytes };
  // GET only: per-gallery sizes for Braid's storage manager. Every review still in the database is not purged yet;
  // bytes include unreceipted reservations, and images come from the published manifest (not the upload rows).
  if (!reviewID) {
    const { results } = await env.DB.prepare(`SELECT r.id, coalesce(sum(u.bytes), 0) AS bytes,
      CASE WHEN json_type(r.manifest, '$.images') = 'array' THEN json_array_length(r.manifest, '$.images') ELSE 0 END AS images,
      r.last_client_edit AS lastClientEditAt
      FROM reviews r LEFT JOIN hosted_uploads u ON u.review_id = r.id GROUP BY r.id`).all();
    body.galleries = results.map(g => ({ id: g.id, bytes: g.bytes, images: g.images, lastClientEditAt: g.lastClientEditAt ?? null }));
  }
  return json(body);
}

async function uploadHostedImage(req, env, reviewID, kind, name) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  const size = Number(req.headers.get('Content-Length'));
  const digest = req.headers.get('X-Braid-SHA256') || '';
  if (!CONTENT_NAME.test(name) || !HEX.test(digest) || !name.endsWith('-' + digest.slice(0, 16))) return json({ error: 'bad-content-name' }, 400);
  if (req.headers.get('Content-Type') !== 'image/jpeg' || !Number.isSafeInteger(size) || size < 4) return json({ error: 'bad-image' }, 400);
  if (size > MAX_HOSTED_IMAGE_BYTES) return json({ error: 'image-too-large' }, 413);
  const headers = { 'Content-Length': String(size), 'X-Braid-SHA256': digest };
  if (req.headers.get('X-Braid-Repair') === '1') headers['X-Braid-Repair'] = '1';
  try {
    return await imageStore(env, reviewID, imageShard(name)).fetch(new Request(
      `https://review-storage.internal/objects/${reviewID}/${kind}/${name}`, { method: 'PUT', headers, body: req.body, duplex: 'half' }));
  } catch {
    return json({ error: 'retry-upload' }, 503);
  }
}

// Called by the private image shard after it has verified the body, while holding its serialization queue.
export async function reserveHostedImage(env, reviewID, kind, name, digest, size, repair) {
  const budget = hostedBudget(env);
  if (budget == null) return json({ error: 'storage-unavailable' }, 503);
  if (await storageReviewState(env, reviewID) === 'closed') return json({ error: 'files-deleted' }, 410);
  if (await hostedIsRetired(env, reviewID)) return retiredResponse();
  if (repair) {
    const committed = await env.DB.prepare(`SELECT 1 AS ok FROM hosted_manifest_files
      WHERE review_id = ? AND kind = ? AND name = ? AND sha256 = ?
      AND EXISTS (SELECT 1 FROM invites WHERE review_id = ?)`).bind(reviewID, kind, name, digest, reviewID).first();
    if (!committed) return json({ error: 'repair-not-committed' }, 409);
  }

  // Refresh and reserve in one D1 transaction. Once the retirement fence wins, this ID cannot gain a reservation.
  await env.DB.batch([refreshHostedDraft(env, reviewID, Date.now()), env.DB.prepare(`INSERT INTO hosted_uploads (review_id, kind, name, sha256, bytes)
    SELECT ?, ?, ?, ?, ? FROM hosted_storage WHERE id = 1 AND reserved_bytes <= ? - ?
    AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')
    AND NOT EXISTS (SELECT 1 FROM reviews WHERE id = ? AND status = 'closed')
    ON CONFLICT(review_id, kind, name) DO NOTHING`).bind(reviewID, kind, name, digest, size, budget, size, reviewID, reviewID)]);
  const reservation = await env.DB.prepare(`SELECT u.sha256, u.bytes FROM hosted_uploads u
    JOIN hosted_lifecycle l USING (review_id) WHERE u.review_id = ? AND u.kind = ? AND u.name = ? AND l.state = 'live'`)
    .bind(reviewID, kind, name).first();
  if (!reservation && await hostedIsRetired(env, reviewID)) return retiredResponse();
  if (!reservation) return json({ error: 'storage-budget-exceeded' }, 409);
  if (reservation.sha256 !== digest || reservation.bytes !== size) return json({ error: 'content-conflict' }, 409);

  return null;
}

export async function settleHostedImage(env, reviewID, kind, name) {
  await env.DB.prepare(`UPDATE hosted_uploads SET stored = 1 WHERE review_id = ? AND kind = ? AND name = ? AND stored = 0
    AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'live')`).bind(reviewID, kind, name, reviewID).run();
  if (await hostedIsRetired(env, reviewID)) return retiredResponse();
  return json({ ok: true });
}

export async function storageReviewState(env, reviewID) {
  return (await env.DB.prepare(`SELECT CASE WHEN l.state = 'live' AND r.status = 'closed' THEN 'closed' ELSE l.state END AS state
    FROM hosted_lifecycle l LEFT JOIN reviews r ON r.id = l.review_id WHERE l.review_id = ?`).bind(reviewID).first())?.state;
}

async function reviewImage(env, req, url, reviewID, kind, name, localCache = {}) {
  if (!env.REVIEW_IMAGES) return asset(env, req, url, `/reviews/${reviewID}/${kind}/${name}.jpg`, localCache);
  const file = await env.DB.prepare(`SELECT f.sha256 FROM hosted_manifest_files f JOIN hosted_lifecycle l USING(review_id)
    WHERE f.review_id = ? AND f.kind = ? AND f.name = ? AND l.state = 'live'
    AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.id = f.review_id AND r.status = 'closed')`)
    .bind(reviewID, kind, name).first();
  if (!file) return json({ error: 'not-found' }, 404);
  try {
    return await imageStore(env, reviewID, imageShard(name)).fetch(new Request(
      `https://review-storage.internal/objects/${reviewID}/${kind}/${name}`, { headers: { 'X-Braid-SHA256': file.sha256 } }));
  } catch {
    return json({ error: 'storage-unavailable' }, 503);
  }
}

// A new review: its gallery data (collections and images) and the starting marks, saved together.
async function createReview(env, b) {
  if (!b || !ID.test(b.id || '') || typeof b.title !== 'string' || !b.title || b.title.length > 200) return json({ error: 'bad-request' }, 400);
  if (!/^[0-9a-f]{64}$/.test(b.hostKeyHash || '') || !Number.isInteger(b.expiresAt) || !Number.isInteger(b.purgeAfter) || b.purgeAfter < b.expiresAt) return json({ error: 'bad-request' }, 400);
  const m = b.manifest;
  if (!m || !Array.isArray(m.images) || !Array.isArray(m.collections) || !Array.isArray(b.marks)) return json({ error: 'bad-request' }, 400);
  const keys = new Set(m.images.map(i => i.key));
  if (keys.size !== m.images.length || ![...keys].every(k => ID.test(k))) return json({ error: 'bad-request' }, 400);
  // Host-only fingerprint of what each key was rendered from (a hash of the variant and its original): lets a resumed
  // share check it is still publishing the same images. Never sent to clients.
  const ids = b.identities;
  if (!ids || typeof ids !== 'object' || Object.keys(ids).length !== keys.size || ![...keys].every(k => /^[0-9a-f]{64}$/.test(ids[k] || ''))) return json({ error: 'bad-request' }, 400);
  // The gallery's files: each image names its grid tile and viewer image, and every file's sha256 is committed with the
  // manifest (host-only), so a resumed share can check exactly what is published.
  const sums = b.checksums, NAME = /^[A-Za-z0-9_-]{8,64}$/;
  if (!sums || typeof sums !== 'object' || !m.images.every(i => NAME.test(i.thumb || '') && NAME.test(i.preview || '') && HEX.test(sums[i.thumb] || '') && HEX.test(sums[i.preview] || ''))) return json({ error: 'bad-request' }, 400);
  const hostedFiles = env.REVIEW_IMAGES ? m.images.flatMap(i => [['t', i.thumb, sums[i.thumb]], ['p', i.preview, sums[i.preview]]]) : [];
  if (env.REVIEW_IMAGES && (!hostedFiles.length || !m.images.every(i => i.thumb === i.key + '-' + sums[i.thumb].slice(0, 16) &&
      i.preview === i.key + '-' + sums[i.preview].slice(0, 16)))) return json({ error: 'bad-content-name' }, 400);
  const hostedFilesJSON = JSON.stringify(hostedFiles);
  const missingFiles = () => env.DB.prepare(`SELECT 1 AS missing FROM json_each(?) AS file WHERE NOT EXISTS (
    SELECT 1 FROM hosted_uploads WHERE review_id = ?
    AND kind = json_extract(file.value, '$[0]') AND name = json_extract(file.value, '$[1]')
    AND sha256 = json_extract(file.value, '$[2]') AND stored = 1) LIMIT 1`).bind(hostedFilesJSON, b.id).first();
  for (const x of b.marks) if (!keys.has(x.k) || !Number.isInteger(x.rating) || x.rating < 0 || x.rating > 5 || !Number.isInteger(x.color) || x.color < 0 || x.color > 7) return json({ error: 'bad-request' }, 400);
  // An existing review can be replaced only while it is still a draft (no invite yet) and by the same host key: a retry
  // after a failed check republishes the photographer's current images and marks. Once an invite exists it's committed.
  // The early check is only a shortcut: the replacement batch itself starts with a guard that fails (rolling the whole
  // batch back) if an invite exists or the host key differs at commit time, so an invite created meanwhile always wins.
  const committedOrForeign = async () => {
    const e = await env.DB.prepare('SELECT host_hash, (SELECT count(*) FROM invites WHERE review_id = reviews.id) AS invites FROM reviews WHERE id = ?').bind(b.id).first();
    return e && (e.invites > 0 || e.host_hash !== b.hostKeyHash) ? e : null;
  };
  if (await hostedIsRetired(env, b.id)) return retiredResponse();
  if (await committedOrForeign()) return json({ error: 'exists' }, 409);
  if (hostedFiles.length && await missingFiles()) return json({ error: 'missing-upload' }, 422);
  const existing = await env.DB.prepare('SELECT 1 AS x FROM reviews WHERE id = ?').bind(b.id).first();
  const now = Date.now();
  const rows = b.marks.flatMap(x => [[x.k, 'rating', x.rating], [x.k, 'color', x.color]]);
  const starting = JSON.stringify(b.marks.map(x => ({ k: x.k, rating: x.rating, color: x.color })));
  const identities = JSON.stringify(ids);
  const checksums = JSON.stringify(Object.fromEntries(m.images.flatMap(i => [[i.thumb, sums[i.thumb]], [i.preview, sums[i.preview]]])));
  const stmts = existing
    ? [env.DB.prepare(`INSERT INTO batch_guard (must_be_null) SELECT NULL WHERE EXISTS (SELECT 1 FROM invites WHERE review_id = ?)
                       OR NOT EXISTS (SELECT 1 FROM reviews WHERE id = ? AND host_hash = ?)`).bind(b.id, b.id, b.hostKeyHash),
       env.DB.prepare('DELETE FROM marks WHERE review_id = ?').bind(b.id), env.DB.prepare('DELETE FROM journal WHERE review_id = ?').bind(b.id),
       env.DB.prepare('UPDATE reviews SET title = ?, expires_at = ?, purge_after = ?, manifest = ?, starting = ?, identities = ?, checksums = ?, mark_seq = ? WHERE id = ?')
         .bind(b.title, b.expiresAt, b.purgeAfter, JSON.stringify(m), starting, identities, checksums, rows.length, b.id)]
    : [env.DB.prepare('INSERT INTO reviews (id, title, expires_at, purge_after, status, version, host_hash, manifest, starting, identities, checksums, mark_seq, created_at) VALUES (?, ?, ?, ?, \'open\', 1, ?, ?, ?, ?, ?, ?, ?)')
         .bind(b.id, b.title, b.expiresAt, b.purgeAfter, b.hostKeyHash, JSON.stringify(m), starting, identities, checksums, rows.length, now)];
  for (let i = 0; i < rows.length; i += 20) {
    const part = rows.slice(i, i + 20);
    stmts.push(env.DB.prepare('INSERT INTO marks (review_id, variant_key, field, value, rev, seq) VALUES ' + part.map(() => '(?, ?, ?, ?, 1, ?)').join(', '))
      .bind(...part.flatMap((r, j) => [b.id, ...r, i + j + 1])));
  }
  if (hostedFiles.length) {
    stmts.unshift(refreshHostedDraft(env, b.id, now), hostedLiveGuard(env, b.id));
    stmts.push(env.DB.prepare('DELETE FROM hosted_manifest_files WHERE review_id = ?').bind(b.id),
      env.DB.prepare(`INSERT INTO hosted_manifest_files (review_id, kind, name, sha256)
        SELECT ?, json_extract(value, '$[0]'), json_extract(value, '$[1]'), json_extract(value, '$[2]') FROM json_each(?)`)
        .bind(b.id, hostedFilesJSON));
  }
  try { await env.DB.batch(stmts); }
  catch (e) {
    // The guard (an invite was created, or another key took the id, between the check and the batch), or a concurrent
    // first create of the same id: nothing was changed.
    if (await hostedIsRetired(env, b.id)) return retiredResponse();
    if (await committedOrForeign()) return json({ error: 'exists' }, 409);
    throw e;
  }
  return json({ ok: true, id: b.id, replaced: !!existing });
}

async function hostManage(req, env, r, action) {
  const now = Date.now();
  if (action === 'status' && req.method === 'GET') {
    const inv = await env.DB.prepare('SELECT id, label, role, expires_at AS expiresAt, revoked FROM invites WHERE review_id = ? ORDER BY rowid').bind(r.id).all();
    // Upgraded v11 galleries keep a 30-day picks window after the photos go; the Mac needs to know which happened.
    const clear = await env.DB.prepare(`SELECT ${filesCleared('reviews')} AS photosCleared FROM reviews WHERE id = ?`).bind(r.id).first();
    return json({ id: r.id, title: r.title, expiresAt: r.expires_at, purgeAfter: r.purge_after, status: r.status, open: r.status === 'open' && now <= r.expires_at,
                  photosCleared: !!clear?.photosCleared, invites: inv.results, lastClientEditAt: r.last_client_edit || null });
  }
  if (action === 'committed' && req.method === 'GET') {
    // What a resumed share must publish under: whether an invite exists (then the review is final), the image
    // fingerprints, gallery list and starting marks it was created with.
    const row = await env.DB.prepare('SELECT manifest, starting, identities, checksums, (SELECT count(*) FROM invites WHERE review_id = reviews.id) AS invites FROM reviews WHERE id = ?').bind(r.id).first();
    if (!row) return json({ error: 'not-found' }, 404);
    return new Response('{"committed":' + (row.invites > 0) + ',"identities":' + (row.identities || '{}') + ',"checksums":' + (row.checksums || '{}') +
                        ',"manifest":' + row.manifest + ',"marks":' + (row.starting || '[]') + '}',
                        { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
  }
  if (action === 'starting' && req.method === 'GET') {
    const row = await env.DB.prepare('SELECT starting FROM reviews WHERE id = ?').bind(r.id).first();
    if (!row) return json({ error: 'not-found' }, 404);
    return new Response('{"marks":' + (row.starting || '[]') + '}', { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
  }
  if (req.method !== 'POST') return json({ error: 'not-found' }, 404);
  const b = await req.json().catch(() => ({}));
  if (action === 'delete-files') {
    if (!env.REVIEW_IMAGES) return json({ error: 'delete-files-unavailable' }, 501);
    // One batch: claim a still-live, eligible review, close the image-write path, clamp this gallery's purge to one
    // week, and move the lifecycle deadline to the same moment (the host keeps syncing picks until the sweep may
    // retire it). Marks and their journal stay live. The token is the proof that this request's claim matched: both
    // later updates require it, so a Delete refused because the gallery was already closed, retiring or not live
    // changes nothing. Both deadlines use the database clock. Expiry is strict (<) and an invite is active through
    // its exact deadline (>=), so at that instant exactly one of "link works" and "may clear" holds.
    const token = randomToken();
    const [, claim] = await env.DB.batch([
      env.DB.prepare(`INSERT OR REPLACE INTO delete_claim (review_id, token, claimed_at)
        SELECT id, ?, ${DB_NOW} FROM reviews
        WHERE id = ? AND status = 'open'
        AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = reviews.id AND state = 'live')
        AND (expires_at < ${DB_NOW} OR NOT EXISTS
          (SELECT 1 FROM invites WHERE review_id = reviews.id AND revoked = 0 AND expires_at >= ${DB_NOW}))`)
        .bind(token, r.id),
      env.DB.prepare(`UPDATE reviews SET status = 'closed', expires_at = min(expires_at, ${DB_NOW}),
        purge_after = min(purge_after, ${DB_NOW} + ${PURGE_CLAMP_MS})
        WHERE id = ? AND status = 'open'
        AND EXISTS (SELECT 1 FROM delete_claim WHERE review_id = ? AND token = ?)`)
        .bind(r.id, r.id, token),
      env.DB.prepare(`UPDATE hosted_lifecycle SET due_at = (SELECT purge_after FROM reviews WHERE id = ?)
        WHERE review_id = ? AND state = 'live'
        AND EXISTS (SELECT 1 FROM delete_claim WHERE review_id = ? AND token = ?)
        AND EXISTS (SELECT 1 FROM reviews WHERE id = ? AND status = 'closed')`)
        .bind(r.id, r.id, r.id, token, r.id),
      // The retry is queued with the closure itself, so a failed clear (or a lost catch below) is still finished by
      // the cron. Two minutes out, so the inline clear just below normally removes it first.
      env.DB.prepare(`INSERT OR IGNORE INTO cleanup_retry (review_id, next_try_at, attempts)
        SELECT review_id, ${DB_NOW} + 120000, 0 FROM delete_claim WHERE review_id = ? AND token = ?`)
        .bind(r.id, token),
      env.DB.prepare('DELETE FROM delete_claim WHERE review_id = ? AND token = ?').bind(r.id, token),
    ]);
    if (!claim.meta.changes) {
      if (await hostedIsRetired(env, r.id)) return retiredResponse();
      // A retry of a Delete that already completed is the same result, with no deadline moved. A closed gallery with
      // a queued retry may run the bounded clear again even though it has invite records (all revoked or expired by
      // the closure); one without a queued retry keeps the refusal. A queued Delete on a gallery without invites (a
      // draft) has no other path, so it finishes here too.
      const cur = await env.DB.prepare(`SELECT status, ${filesCleared('reviews')} AS cleared,
        EXISTS (SELECT 1 FROM invites WHERE review_id = reviews.id) AS invites,
        EXISTS (SELECT 1 FROM cleanup_retry WHERE review_id = reviews.id) AS queued FROM reviews WHERE id = ?`).bind(r.id).first();
      if (cur?.status === 'closed' && cur.cleared) return json({ filesDeleted: true });
      if (cur?.status === 'closed' && (!cur.invites || cur.queued)) {
        try {
          await clearGalleryFilesBounded(env, r.id);
          return json({ filesDeleted: true });
        } catch {
          return json({ error: 'retry-delete-files' }, 503);
        }
      }
      return json({ error: 'review-still-open' }, 409);
    }
    try {
      await clearGalleryFilesBounded(env, r.id);
    } catch {
      return json({ error: 'retry-delete-files' }, 503);
    }
    return json({ filesDeleted: true });
  }
  if (action === 'invites') {
    if (r.status === 'closed') return json({ error: 'files-deleted' }, 410);
    // Braid makes the invite's token and id and sends only the token's hash, so a retry after a lost reply is the same
    // invite (never a second one), and the token never needs to come back from the service.
    if (!['view', 'pick'].includes(b.role) || typeof b.label !== 'string' || !b.label || b.label.length > 80 || !ID.test(b.inviteId || '') || !/^[0-9a-f]{64}$/.test(b.tokenHash || '')) return json({ error: 'bad-request' }, 400);
    const expiresAt = Math.min(Number.isInteger(b.expiresAt) ? b.expiresAt : r.expires_at, r.expires_at);
    const insert = env.DB.prepare('INSERT OR IGNORE INTO invites (id, review_id, token_hash, role, label, expires_at) VALUES (?, ?, ?, ?, ?, ?)').bind(b.inviteId, r.id, b.tokenHash, b.role, b.label, expiresAt);
    if (env.REVIEW_IMAGES) {
      try {
        await env.DB.batch([hostedLiveGuard(env, r.id), insert, env.DB.prepare(`UPDATE hosted_lifecycle SET committed = 1,
          due_at = (SELECT max(purge_after, expires_at) FROM reviews WHERE id = ?)
          WHERE review_id = ? AND committed = 0 AND EXISTS (SELECT 1 FROM invites WHERE review_id = ?)`)
          .bind(r.id, r.id, r.id)]);
      } catch (error) {
        if (await hostedIsRetired(env, r.id)) return retiredResponse();
        throw error;
      }
    } else await insert.run();
    const inv = await env.DB.prepare('SELECT review_id, token_hash, expires_at FROM invites WHERE id = ?').bind(b.inviteId).first();
    if (!inv || inv.review_id !== r.id || inv.token_hash !== b.tokenHash) return json({ error: 'exists' }, 409);
    return json({ inviteId: b.inviteId, expiresAt: inv.expires_at });
  }

  if (action === 'restore-link') {
    if (!ID.test(b.inviteId || '')) return json({ error: 'bad-request' }, 400);
    // Restore only the original invite. The same SQL statement checks the delete fence and its deadline, all on the
    // database clock so a skewed Worker clock cannot revive a link the database has already expired.
    const lifecycle = env.REVIEW_IMAGES
      ? "AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = invites.review_id AND state = 'live' AND committed = 1)"
      : "";
    const invite = await env.DB.prepare(`UPDATE invites SET revoked = 0
      WHERE id = ? AND review_id = ? AND expires_at > ${DB_NOW}
      AND EXISTS (SELECT 1 FROM reviews WHERE id = invites.review_id AND status = 'open'
        AND expires_at > ${DB_NOW} AND purge_after > ${DB_NOW})
      ${lifecycle} RETURNING expires_at`).bind(b.inviteId, r.id).first();
    if (!invite) return json({ error: 'link-unavailable' }, 409);
    return json({ restored: true });
  }

  if (action === 'revoke') {
    if (b.all === true) await env.DB.prepare('UPDATE invites SET revoked = 1 WHERE review_id = ?').bind(r.id).run();
    else if (ID.test(b.inviteId || '')) await env.DB.prepare('UPDATE invites SET revoked = 1 WHERE review_id = ? AND id = ?').bind(r.id, b.inviteId).run();
    else return json({ error: 'bad-request' }, 400);
    return json({ ok: true });
  }
  if (action === 'expire') {
    // Closes (or reopens until) the given time for clients; the host keeps access until the purge date.
    if (!Number.isInteger(b.expiresAt) || b.expiresAt > r.purge_after) return json({ error: 'bad-request' }, 400);
    // The UPDATE itself requires an open, live review, so a close or retirement that raced ahead cannot be reported as
    // success. A gallery the cron has already closed is irreversible.
    const lifecycle = env.REVIEW_IMAGES ? "AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = reviews.id AND state = 'live')" : '';
    const changed = await env.DB.prepare(`UPDATE reviews SET expires_at = ? WHERE id = ? AND status = 'open' ${lifecycle}`)
      .bind(b.expiresAt, r.id).run();
    if (!changed.meta.changes) {
      // One read of the lifecycle state and the review status together: a retirement between two reads used to answer
      // "not open" for a gallery that was already gone. Review row + non-live lifecycle (or no row at all) is retired.
      const cur = await (env.REVIEW_IMAGES
        ? env.DB.prepare(`SELECT r.status, r.expires_at, l.state FROM reviews r
            LEFT JOIN hosted_lifecycle l ON l.review_id = r.id WHERE r.id = ?`).bind(r.id)
        : env.DB.prepare("SELECT status, expires_at, 'live' AS state FROM reviews WHERE id = ?").bind(r.id)).first();
      if (cur && cur.state !== 'live') return retiredResponse();
      if (cur?.status === 'closed') return json({ error: 'files-deleted', status: 'closed', expiresAt: cur.expires_at }, 410);
      if (!cur && env.REVIEW_IMAGES) return retiredResponse();
      return json({ error: 'not-open', status: cur?.status ?? 'gone', expiresAt: cur?.expires_at ?? null }, 409);
    }
    return json({ ok: true, expiresAt: b.expiresAt });
  }
  return json({ error: 'not-found' }, 404);
}

// Publish is create-only per invite: a retry returns the same card, and can never overwrite the title or the cover.
// The cover is one per gallery, so the first publish also seeds it unless a cover already exists.
async function publishPreview(req, env, r) {
  const b = await req.json().catch(() => null);
  if (!b || !ID.test(b.inviteId || '') || typeof b.title !== 'string' || !b.title || b.title.length > 200
      || typeof b.line !== 'string' || b.line.length > 300 || !ID.test(b.imageKey || '')) return json({ error: 'bad-request' }, 400);
  const row = await env.DB.prepare(`SELECT manifest, EXISTS (SELECT 1 FROM invites WHERE id = ? AND review_id = reviews.id) AS invite
    FROM reviews WHERE id = ?`).bind(b.inviteId, r.id).first();
  if (!row || !row.invite) return json({ error: 'not-found' }, 404);
  let images = [];
  try { images = JSON.parse(row.manifest).images || []; } catch (_) {}
  if (!images.some(image => image.key === b.imageKey)) return json({ error: 'bad-request' }, 400);
  try { await ensurePreviewTables(env); }
  catch { return json({ error: 'storage-unavailable' }, 503); }
  try {
    await env.DB.batch([
      ...(env.REVIEW_IMAGES ? [hostedLiveGuard(env, r.id)] : []),
      // The cover goes in before the preview row: a seed can only exist while no preview is published, so this
      // publish's auto-cover choice replaces one, and a different photo advances the revision. A photographer's
      // cover is never replaced, and once the preview exists a later publish never touches the cover.
      env.DB.prepare(`INSERT INTO review_cover (review_id, image_key, rev, source)
        SELECT ?, ?, 1, 'auto' WHERE NOT EXISTS (SELECT 1 FROM review_preview WHERE review_id = ?)
        ON CONFLICT (review_id) DO UPDATE SET image_key = excluded.image_key, source = 'auto',
          rev = review_cover.rev + (review_cover.image_key <> excluded.image_key)
        WHERE review_cover.source = 'seed'`).bind(r.id, b.imageKey, r.id),
      env.DB.prepare(`INSERT OR IGNORE INTO review_preview (preview_id, review_id, invite_id, title, line, created_at)
        SELECT ?, ?, ?, ?, ?, ?`).bind(randomToken(16), r.id, b.inviteId, b.title, b.line, Date.now()),
    ]);
  } catch (error) {
    if (await hostedIsRetired(env, r.id)) return retiredResponse();
    throw error;
  }
  const card = await hostPreviewCard(env, r.id, b.inviteId);
  return card ? json(CARD_SHAPE(card)) : json({ error: 'not-found' }, 404);
}

// The title edit compares the revision the Share card showed; a stale card gets the current one instead of overwriting.
// The card id comes with the revision because switching off and publishing again restarts the revision at 1.
async function editPreview(req, env, r) {
  const b = await req.json().catch(() => null);
  if (!b || !ID.test(b.inviteId || '') || typeof b.title !== 'string' || !b.title || b.title.length > 200
      || !ID.test(b.previewId || '') || !Number.isInteger(b.baseRev) || b.baseRev < 1) return json({ error: 'bad-request' }, 400);
  let changed = 0;
  try {
    changed = (await env.DB.prepare(`UPDATE review_preview SET title = ?, rev = rev + 1
      WHERE review_id = ? AND invite_id = ? AND preview_id = ? AND rev = ?`)
      .bind(b.title, r.id, b.inviteId, b.previewId, b.baseRev).run()).meta.changes;
  } catch (error) { if (!missingTable(error)) throw error; }
  const card = await hostPreviewCard(env, r.id, b.inviteId);
  if (!card) return json({ error: 'not-found' }, 404);
  return json(CARD_SHAPE(card), changed ? 200 : 409);
}

async function deletePreview(env, r, inviteId) {
  if (!ID.test(inviteId || '')) return json({ error: 'bad-request' }, 400);
  try { await env.DB.prepare('DELETE FROM review_preview WHERE review_id = ? AND invite_id = ?').bind(r.id, inviteId).run(); }
  catch (error) { if (!missingTable(error)) throw error; }
  return json({ ok: true });
}

// The public cover carries only pixels, with exactly the segments Braid's own JPEGStrip keeps: JFIF (APP0), the ICC
// profile (APP2), Adobe's colour transform (APP14), the frame and tables, and an orientation-only EXIF. Every marker
// is walked to EOI, so other APPn segments and comments before, between or after scans are dropped. A truncated file,
// a marker JPEGStrip doesn't recognise, or any byte after EOI is refused.
function stripJpegMetadata(data) {
  const b = new Uint8Array(data);
  if (b.length <= 4 || b[0] !== 0xff || b[1] !== 0xd8) return null;
  const has = (bytes, text) => { for (let k = 0; k < text.length; k++) if (bytes[k] !== text.charCodeAt(k)) return false; return true; };
  const header = [], body = [];                                                 // segments before the first scan, then the scans
  let i = 2, inScans = false, sawEOI = false, eoiEnd = 0, orientation = 1;
  while (i < b.length) {
    if (inScans && b[i] !== 0xff) {                                             // entropy-coded data up to the next real marker
      let j = i;
      while (j + 1 < b.length && !(b[j] === 0xff && b[j + 1] !== 0x00 && !(b[j + 1] >= 0xd0 && b[j + 1] <= 0xd7) && b[j + 1] !== 0xff)) j++;
      if (j + 1 >= b.length) return null;
      body.push(b.subarray(i, j)); i = j; continue;
    }
    if (b[i] !== 0xff || i + 1 >= b.length) return null;
    let j = i + 1;
    while (j < b.length && b[j] === 0xff) j++;                                  // fill bytes
    if (j >= b.length) return null;
    const m = b[j];
    if (inScans && (m === 0x00 || (m >= 0xd0 && m <= 0xd7))) { body.push(new Uint8Array([0xff, m])); i = j + 1; continue; }
    if (m === 0xd9) { body.push(new Uint8Array([0xff, 0xd9])); sawEOI = true; eoiEnd = j + 1; break; }
    if (m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { (inScans ? body : header).push(new Uint8Array([0xff, m])); i = j + 1; continue; }
    if (j + 2 >= b.length) return null;
    const length = (b[j + 1] << 8) | b[j + 2];
    const end = j + 1 + length;
    if (length < 2 || end > b.length) return null;
    const content = b.subarray(j + 3, end);
    const seg = new Uint8Array(end - j + 1);
    seg[0] = 0xff; seg[1] = m; seg.set(b.subarray(j + 1, end), 2);
    if (m === 0xda) { body.push(seg); inScans = true; }                         // start of a scan
    else if (m === 0xc4 || m === 0xdb || m === 0xdd || m === 0xdc || m === 0xcc) (inScans ? body : header).push(seg);
    else if (m >= 0xc0 && m <= 0xcf) { if (inScans) return null; header.push(seg); }   // the frame header
    else if (m === 0xe0 && !inScans && has(content, 'JFIF\0')) header.push(seg);
    else if (m === 0xe2 && !inScans && has(content, 'ICC_PROFILE\0')) header.push(seg);
    else if (m === 0xee && !inScans && has(content, 'Adobe')) header.push(seg);
    else if (m === 0xe1) {
      if (!inScans && has(content, 'Exif\0\0')) { const o = exifOrientation(content.subarray(6)); if (o) orientation = o; }
    } else if (!(m === 0xfe || (m >= 0xe0 && m <= 0xef))) return null;
    i = end;
  }
  if (!sawEOI || !inScans || eoiEnd !== b.length) return null;
  // JFIF first, then the orientation EXIF if needed, then the rest of the header in its order, then the scans.
  const parts = [new Uint8Array([0xff, 0xd8])];
  for (const h of header) if (h[1] === 0xe0) parts.push(h);
  if (orientation !== 1) parts.push(minimalExif(orientation));
  for (const h of header) if (h[1] !== 0xe0) parts.push(h);
  for (const p of body) parts.push(p);
  const out = new Uint8Array(parts.reduce((n, part) => n + part.length, 0));
  let at = 0;
  for (const part of parts) { out.set(part, at); at += part.length; }
  return out;
}

// Orientation (tag 0x0112) from IFD0 of a TIFF/EXIF block, read the way JPEGStrip reads it.
function exifOrientation(t) {
  if (t.length < 8) return null;
  const big = t[0] === 0x4d;
  const u16 = o => o + 1 < t.length ? (big ? t[o] << 8 | t[o + 1] : t[o + 1] << 8 | t[o]) : null;
  const u32 = o => { const a = u16(o), c = u16(o + 2); return a === null || c === null ? null : big ? a * 65536 + c : c * 65536 + a; };
  const ifd = u32(4), n = ifd === null ? null : u16(ifd);
  if (n === null) return null;
  for (let k = 0; k < n; k++) {
    const e = ifd + 2 + k * 12, tag = u16(e);
    if (tag === null) return null;
    if (tag === 0x0112) return u16(e + 8);
  }
  return null;
}

// The smallest EXIF that carries only the orientation, so the display doesn't change.
function minimalExif(orientation) {
  const content = [0x45, 0x78, 0x69, 0x66, 0, 0, 0x4d, 0x4d, 0, 0x2a, 0, 0, 0, 8, 0, 1,
    0x01, 0x12, 0, 3, 0, 0, 0, 1, orientation >> 8, orientation & 0xff, 0, 0, 0, 0, 0, 0];
  const len = content.length + 2;
  return new Uint8Array([0xff, 0xe1, len >> 8, len & 0xff, ...content]);
}

// Public card reads: no cookies, no conditional headers, no-store on every outcome. Non-live is the generic page.
async function publicPreview(req, env, url, previewId, cover) {
  const headers = { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff' };
  const head = req.method === 'HEAD';
  const card = await publicPreviewCard(env, previewId);
  if (cover) {
    if (!card) return new Response(null, { status: 404, headers });
    // The viewer image when it is small enough for a link preview, else its grid tile. Recheck liveness after the
    // bytes are in hand, so a revoke or expiry that commits meanwhile still withdraws the card.
    const usePreview = Number.isSafeInteger(card.p_bytes) && card.p_bytes <= 300 * 1024;
    let bytes;
    try {
      // A fresh request: the caller's cookie and If-None-Match/If-Modified-Since must never reach the asset store,
      // where a 304 for one URL could later be served as a 404.
      const image = await reviewImage(env, new Request(url), url, card.review_id, usePreview ? 'p' : 't', usePreview ? card.preview : card.thumb);
      if (image.status !== 200) return new Response(null, { status: 404, headers });
      bytes = await image.arrayBuffer();
    } catch { return new Response(null, { status: 404, headers }); }
    if (!(await publicPreviewCard(env, previewId))) return new Response(null, { status: 404, headers });
    const stripped = stripJpegMetadata(bytes);
    if (!stripped) return new Response(null, { status: 404, headers });
    return new Response(head ? null : stripped, { status: 200, headers: { ...headers, 'Content-Type': 'image/jpeg', 'Content-Length': String(stripped.length) } });
  }
  let shell, page;
  try {
    const asset = await env.ASSETS.fetch(new Request(new URL('/index.html', url)));
    shell = await asset.text();
  } catch { return new Response(null, { status: 404, headers }); }
  // The public page is the viewer, not the host app. Rewrite the shell so the withdrawal fallback uses it too.
  shell = shell.replace('<script src="/app.js"></script>', () => '<script src="/p-app.js"></script>');
  page = card ? await withOgTags(shell, card, url.origin) : shell;
  // The card was read before the page was built: a withdrawal committed while rendering must not ship its tags.
  if (card && !(await publicPreviewCard(env, previewId))) page = shell;
  return new Response(head ? null : page, {
    status: 200, headers: { ...headers, 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': CSP } });
}

// Whether this gallery holds the image key. Every created gallery has a mark row per image, so this is the same
// membership the write itself needs. Only legacy (id-less) writes ask.
async function holdsImageKey(env, reviewId, key) {
  return !!(await env.DB.prepare('SELECT 1 AS x FROM marks WHERE review_id = ? AND variant_key = ?').bind(reviewId, key).first());
}

async function writeMark(req, env, s) {
  const b = await req.json().catch(() => null);
  if (!validMark(b)) return json({ error: 'bad-request' }, 400);
  // One session cookie per host: a page that still names its own review must never write into the review a second
  // tab opened. Checked before the role so even a view-only tab sees the switch bar, not a misleading "view only".
  if (b.reviewId !== undefined && b.reviewId !== s.review_id) return json({ error: 'session-switched' }, 409);
  // An old viewer sends no reviewId. Its save is accepted only for an image this session's gallery holds; a key that
  // isn't there means the page is showing another gallery, so show the switch bar instead of writing here.
  if (b.reviewId === undefined && !(await holdsImageKey(env, s.review_id, b.key))) return json({ error: 'session-switched' }, 409);
  if (s.role !== 'pick') return json({ error: 'view-only' }, 403);
  // The network provider's name only (for example a mobile carrier), never the address.
  return commitMark(env, s.review_id, 'invite:' + s.invite_id, String((req.cf && req.cf.asOrganization) || 'unknown').slice(0, 80), b);
}

// The Mac's proof that every pick it knows about was read: only a closed gallery whose whole mark history the Mac's
// confirming read covered may be retired early. No clock is involved. Idempotent: a lost reply retries into
// "finishing", then "gone" once the sweep has retired it.
async function finishHostedReview(req, env, reviewID) {
  if (!env.REVIEW_IMAGES || req.method !== 'POST') return json({ error: 'not-found' }, 404);
  const b = await req.json().catch(() => null);
  if (!b || !Number.isInteger(b.savedThrough) || b.savedThrough < -1) return json({ error: 'bad-request' }, 400);
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return json({ error: 'unauthorized' }, 401);
  const row = await env.DB.prepare(`SELECT r.host_hash, r.status, r.mark_seq, l.state FROM reviews r
    LEFT JOIN hosted_lifecycle l ON l.review_id = r.id WHERE r.id = ?`).bind(reviewID).first();
  if (!row) return json({ gone: true });   // retired, or never existed
  if (!safeEqual(row.host_hash, await sha256(auth.slice(7)))) return json({ error: 'unauthorized' }, 401);
  // A retiring row can only be released back to live while a deadline is still ahead; finish never says "gone" here.
  if (row.state && row.state !== 'live') return json({ finishing: true });
  await env.DB.batch([
    env.DB.prepare(`UPDATE reviews SET status = 'closed', expires_at = min(expires_at, ${DB_NOW}), purge_after = ${DB_NOW} - 1
      WHERE id = ? AND mark_seq <= ?
      AND (status = 'closed' OR expires_at < ${DB_NOW})
      AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = reviews.id AND state = 'live')`).bind(reviewID, b.savedThrough),
    env.DB.prepare(`UPDATE hosted_lifecycle SET due_at = ${DB_NOW} - 1
      WHERE review_id = ? AND state = 'live'
      AND EXISTS (SELECT 1 FROM reviews WHERE id = ? AND purge_after < ${DB_NOW})`).bind(reviewID, reviewID),
  ]);
  const after = await env.DB.prepare(`SELECT purge_after < ${DB_NOW} AS done FROM reviews WHERE id = ?`).bind(reviewID).first();
  return after?.done ? json({ finishing: true }) : json({ error: 'not-ready' }, 409);
}

// The host (Braid on the photographer's Mac): a per-review key, sent as a bearer token, stored only as a hash.
async function hostReview(req, env, reviewId) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ') || !/^[A-Za-z0-9_-]{8,64}$/.test(reviewId)) return null;
  // The purge deadline is checked on the database clock (the Worker's clock may be skewed); a review is still the
  // host's through its exact deadline, matching retirement's strict past check.
  const r = await env.DB.prepare(`SELECT id, title, host_hash, expires_at, purge_after, status, last_client_edit
    FROM reviews WHERE id = ? AND purge_after >= ${DB_NOW}`).bind(reviewId).first();
  if (!r || await hostedIsRetired(env, reviewId)) return null;
  return safeEqual(r.host_hash, await sha256(auth.slice(7))) ? r : null;
}

// The one destructive clear, used by manual Delete and automatic expiry: image shards, upload reservations, the
// manifest-file rows and the manifest itself. Marks and their journal stay readable until the purge date.
async function clearGalleryFiles(env, id, signal) {
  await clearImageShards(env, id, { signal });
  await env.DB.batch([
    env.DB.prepare('DELETE FROM hosted_uploads WHERE review_id = ?').bind(id),
    env.DB.prepare('DELETE FROM hosted_manifest_files WHERE review_id = ?').bind(id),
    env.DB.prepare("UPDATE reviews SET manifest = '{}', starting = NULL, identities = NULL, checksums = NULL WHERE id = ?").bind(id),
  ]);
}

// Photo-clear retries have their own due date, separate from the picks purge schedule. The first failure waits two
// minutes; each later one doubles, capped at an hour.
function scheduleCleanupRetry(env, id) {
  // A delayed failure must not recreate the row after the cron retired the gallery and removed it.
  return env.DB.prepare(`INSERT INTO cleanup_retry (review_id, next_try_at, attempts)
    SELECT r.id, ${DB_NOW} + 2 * 60000, 1 FROM reviews r
    JOIN hosted_lifecycle l ON l.review_id = r.id
    WHERE r.id = ? AND r.status = 'closed' AND l.state = 'live' AND NOT ${filesCleared('r')}
    ON CONFLICT(review_id) DO UPDATE SET
      attempts = cleanup_retry.attempts + 1,
      next_try_at = ${DB_NOW} + (CASE WHEN cleanup_retry.attempts >= 5 THEN ${CLEANUP_MAX_MINUTES}
        ELSE 1 << (cleanup_retry.attempts + 1) END) * 60000`)
    .bind(id);
}

// One bounded attempt: the clear may not hold a tick (or a manual Delete) hostage. A timeout aborts the shard fetches
// that support a signal; success also removes any older retry row.
async function clearGalleryFilesBounded(env, id) {
  const controller = new AbortController();
  let timer;
  try {
    await Promise.race([
      clearGalleryFiles(env, id, controller.signal),
      new Promise((_, reject) => {
        timer = setTimeout(() => { controller.abort(); reject(new Error('cleanup-timeout')); }, CLEANUP_TIMEOUT_MS);
      }),
    ]);
  } catch (error) {
    await scheduleCleanupRetry(env, id).run();
    throw error;
  } finally {
    clearTimeout(timer);
  }
  await env.DB.prepare('DELETE FROM cleanup_retry WHERE review_id = ?').bind(id).run();
}

// A closed gallery is done only when the manifest is empty and no upload or manifest-file row remains; anything else is
// picked up again by a later tick.
const filesCleared = alias => `(${alias}.manifest = '{}'
  AND NOT EXISTS (SELECT 1 FROM hosted_uploads WHERE review_id = ${alias}.id)
  AND NOT EXISTS (SELECT 1 FROM hosted_manifest_files WHERE review_id = ${alias}.id))`;

// Close and clear at most four galleries per tick. Due retries are taken first and always keep a slot, so a steady
// stream of fresh expiries cannot starve a manual Delete or a photo clear; fresh expiries fill the rest. A closed
// gallery without invites can only be a queued manual Delete, so retries do not require invites. The four clears run
// together, each with its own timeout, so one stalled shard cannot delay the others.
async function closeExpiredGalleries(env) {
  const ids = [];
  const retries = await env.DB.prepare(`SELECT r.id FROM cleanup_retry q
    JOIN reviews r ON r.id = q.review_id JOIN hosted_lifecycle l ON l.review_id = r.id
    WHERE q.next_try_at <= ${DB_NOW} AND r.status = 'closed' AND l.state = 'live'
    AND NOT ${filesCleared('r')}
    ORDER BY q.next_try_at, r.id LIMIT ${CLOSE_BATCH}`).all();
  const fresh = await env.DB.prepare(`SELECT r.id FROM reviews r
    WHERE r.status = 'open' AND r.expires_at < ${DB_NOW} AND NOT ${filesCleared('r')}
    AND EXISTS (SELECT 1 FROM invites WHERE review_id = r.id)
    AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = r.id AND state = 'live')
    ORDER BY r.id LIMIT ${retries.results.length ? CLOSE_BATCH - 1 : CLOSE_BATCH}`).all();
  for (const { id } of fresh.results) {
    // The retry row is written in the same batch as the closure: a crash before the clear begins cannot leave a
    // closed gallery with no queued retry.
    const [claimed] = await env.DB.batch([
      env.DB.prepare(`UPDATE reviews SET status = 'closed'
        WHERE id = ? AND status = 'open' AND expires_at < ${DB_NOW}
        AND EXISTS (SELECT 1 FROM invites WHERE review_id = reviews.id)
        AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = reviews.id AND state = 'live')`).bind(id),
      env.DB.prepare(`INSERT OR IGNORE INTO cleanup_retry (review_id, next_try_at, attempts)
        SELECT id, ${DB_NOW}, 0 FROM reviews WHERE id = ? AND status = 'closed' AND NOT ${filesCleared('reviews')}`).bind(id),
    ]);
    if (claimed.meta.changes) ids.push(id);
  }
  ids.push(...retries.results.map(row => row.id).slice(0, CLOSE_BATCH - ids.length));
  await Promise.all(ids.map(id => clearGalleryFilesBounded(env, id).catch(() => {})));
}

// Select one indexed job, all deadlines on the database clock (never the Worker's). A review row is retired only
// once its due_at, expires_at and purge_after are all strictly past; an upload-only ID (no review row) keeps its
// due_at inactivity timeout. Updating due_at lets other due reviews make progress when this job hits an R2 error.
async function claimHostedSweep(env) {
  const token = randomToken();
  const claims = await env.DB.batch([
    env.DB.prepare(`WITH
      active AS (SELECT l.review_id, l.due_at FROM hosted_lifecycle l WHERE l.state = 'live' AND l.due_at < ${DB_NOW}
        AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.id = l.review_id
          AND (r.expires_at >= ${DB_NOW} OR r.purge_after >= ${DB_NOW}))),
      retries AS (SELECT l.review_id, l.due_at FROM hosted_lifecycle l WHERE l.state = 'retiring' AND l.due_at <= ${DB_NOW}
        -- A marked row with future deadlines can neither be released to live nor cleared, so leave it for the deadline
        -- instead of re-claiming it every tick. An unmarked one is still claimed: the release puts it back to live.
        AND (NOT EXISTS (SELECT 1 FROM sweep_deleting d WHERE d.review_id = l.review_id)
          OR NOT EXISTS (SELECT 1 FROM reviews r WHERE r.id = l.review_id
            AND (r.expires_at >= ${DB_NOW} OR r.purge_after >= ${DB_NOW})))
        AND NOT EXISTS (SELECT 1 FROM sweep_claim c WHERE c.review_id = l.review_id
          AND c.claimed_at > ${DB_NOW} - ${SWEEP_LEASE_MS})),
      next_job AS (SELECT * FROM active UNION ALL SELECT * FROM retries ORDER BY due_at, review_id LIMIT 1)
      INSERT OR REPLACE INTO sweep_claim (review_id, token, claimed_at)
      SELECT review_id, ?, ${DB_NOW} FROM next_job LIMIT 1`).bind(token),
    env.DB.prepare(`UPDATE hosted_lifecycle SET state = 'retiring', due_at = ${DB_NOW} + ${SWEEP_RETRY_MS}
      WHERE review_id = (SELECT review_id FROM sweep_claim WHERE token = ?)
      AND state IN ('live','retiring')`).bind(token),
  ]);
  if (!claims[1]?.meta.changes) {
    await env.DB.prepare('DELETE FROM sweep_claim WHERE token = ?').bind(token).run();
    return null;
  }
  const claimed = await env.DB.prepare('SELECT review_id FROM sweep_claim WHERE token = ?').bind(token).first();
  return claimed ? { id: claimed.review_id, token } : null;
}

// A retry of an interrupted sweep (the row is already 'retiring') must pass the same database-clock guard as a fresh
// claim: a review row is due only once expires_at AND purge_after are strictly past. If the guard fails, put the row
// back to live at its real deadline instead of clearing it, so the next claim waits for that deadline. A draft's
// inactivity clock was checked when it was first claimed and its due_at was overwritten then; restoring its share
// deadline here is the conservative choice. Returning a row to live also removes its token in this same batch, so an
// older tick that resumes cannot use the claim again. A row whose shard deletion has begun is never returned to live
// (deletion only starts once both deadlines are past, so late or duplicate shard deletes are harmless).
async function releaseEarlySweep(env, id, token) {
  const [released] = await env.DB.batch([
    env.DB.prepare(`UPDATE hosted_lifecycle SET state = 'live',
      due_at = (SELECT max(r.expires_at, r.purge_after) FROM reviews r WHERE r.id = hosted_lifecycle.review_id)
      WHERE review_id = ? AND state = 'retiring'
      AND NOT EXISTS (SELECT 1 FROM sweep_deleting WHERE review_id = ?)
      AND EXISTS (SELECT 1 FROM sweep_claim WHERE review_id = ? AND token = ?)
      AND EXISTS (SELECT 1 FROM reviews r WHERE r.id = hosted_lifecycle.review_id
        AND (r.expires_at >= ${DB_NOW} OR r.purge_after >= ${DB_NOW}))`).bind(id, id, id, token),
    env.DB.prepare(`DELETE FROM sweep_claim WHERE review_id = ? AND token = ?
      AND NOT EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'retiring')`).bind(id, token, id),
  ]);
  return released;
}

// Every destructive step carries this token and the two database-clock deadlines. A no-op guard row is the first
// statement of each batch, so its change count is the gate for continuing to the next step.
const CLAIM_TOKEN = 'EXISTS (SELECT 1 FROM sweep_claim WHERE review_id = ? AND token = ?)';
const SWEEP_DEADLINES = `NOT EXISTS (SELECT 1 FROM reviews r WHERE r.id = ? AND
  (r.expires_at >= ${DB_NOW} OR r.purge_after >= ${DB_NOW}))`;
function sweepGuard(env, id, token) {
  return env.DB.prepare(`UPDATE sweep_claim SET claimed_at = claimed_at
    WHERE review_id = ? AND token = ? AND ${SWEEP_DEADLINES}`).bind(id, token, id);
}
// Renew the claim before each shard. The guarded update extends the lease only while this token still owns the claim;
// once a newer tick has taken over it changes nothing and the old tick stops without touching another shard.
async function renewSweepClaim(env, id, token) {
  return !!(await env.DB.prepare(`UPDATE sweep_claim SET claimed_at = ${DB_NOW}
    WHERE review_id = ? AND token = ? AND ${SWEEP_DEADLINES}`).bind(id, token, id).run()).meta.changes;
}

// Record, in the same D1 batch that proves this tick still holds the claim with both deadlines past, that shard
// deletion is starting. From here a newer tick can never return the gallery to live, so a duplicate or late shard
// delete is harmless; the row stays 'retiring' and a later tick finishes it.
async function beginShardDeletion(env, id, token) {
  const [guard] = await env.DB.batch([
    sweepGuard(env, id, token),
    env.DB.prepare(`INSERT OR IGNORE INTO sweep_deleting (review_id)
      SELECT review_id FROM sweep_claim WHERE review_id = ? AND token = ? AND ${SWEEP_DEADLINES}`)
      .bind(id, token, id),
  ]);
  return !!guard.meta.changes;
}

// Release the storage budget only after every shard confirms deletion. A sweep renews its claim before each shard, so
// a tick that stalled mid-clear stops at the next shard once its lease has expired and a newer tick has taken over.
// Every shard request is bounded on its own: one stalled shard cannot hold a tick (or a manual Delete) hostage.
async function clearImageShards(env, id, { signal, stillClaimed } = {}) {
  for (let shard = 0; shard < IMAGE_SHARDS; ++shard) {
    if (stillClaimed && !(await stillClaimed())) return false;
    const controller = new AbortController();
    const relay = () => controller.abort();
    signal?.addEventListener('abort', relay);
    let timer;
    let result;
    try {
      result = await Promise.race([
        imageStore(env, id, shard).fetch(new Request(
          `https://review-storage.internal/retire/${id}`, { method: 'POST', signal: controller.signal })),
        new Promise((_, reject) => {
          timer = setTimeout(() => { controller.abort(); reject(new Error('shard-timeout')); }, CLEANUP_TIMEOUT_MS);
        }),
      ]);
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', relay);
    }
    if (result.status !== 204) throw new Error('Review storage could not be cleared');
  }
  return true;
}

async function sweepHostedReview(env) {
  const claim = await claimHostedSweep(env);
  if (!claim) return;
  const { id, token } = claim;
  if ((await releaseEarlySweep(env, id, token)).meta.changes) return;
  const stillClaimed = () => renewSweepClaim(env, id, token);
  if (!(await stillClaimed())) return;
  const cleared = await env.DB.prepare('SELECT 1 AS complete FROM hosted_cleaned_storage WHERE review_id = ?').bind(id).first();
  if (!cleared) {
    if (!(await beginShardDeletion(env, id, token))) return;
    if (!(await clearImageShards(env, id, { stillClaimed }))) return;
    const [guard] = await env.DB.batch([
      sweepGuard(env, id, token),
      env.DB.prepare(`INSERT OR IGNORE INTO hosted_cleaned_storage (review_id)
        SELECT review_id FROM hosted_lifecycle WHERE review_id = ? AND state = 'retiring'
        AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, id, token, id),
    ]);
    if (!guard.meta.changes) return;
  }
  // Row counts here are bounded independently of the number of photos or client actions in the shoot.
  // Keep invites until all their session rows have gone. No admission path can add data after the fence.
  // The preview tables may predate this feature only if there is no preview row, so they are deleted when present.
  const previewTables = await env.DB.prepare(`SELECT count(*) AS n FROM sqlite_master
    WHERE type = 'table' AND name IN ('review_cover', 'review_preview')`).first();
  const tables = ['hosted_uploads', 'hosted_manifest_files', 'marks', 'journal', 'fences',
    ...(previewTables?.n === 2 ? ['review_cover', 'review_preview'] : [])];
  const stmts = [sweepGuard(env, id, token)];
  for (const table of tables) {
    stmts.push(env.DB.prepare(`DELETE FROM ${table} WHERE rowid IN (
      SELECT rowid FROM ${table} WHERE review_id = ? LIMIT ?)
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, SWEEP_DATA_BATCH, id, token, id));
  }
  stmts.push(env.DB.prepare(`DELETE FROM sessions WHERE rowid IN (
    SELECT s.rowid FROM invites i JOIN sessions s ON s.invite_id = i.id WHERE i.review_id = ? LIMIT ?)
    AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, SWEEP_DATA_BATCH, id, token, id),
    env.DB.prepare(`DELETE FROM invites WHERE rowid IN (
    SELECT i.rowid FROM invites i WHERE i.review_id = ? AND NOT EXISTS (SELECT 1 FROM sessions s WHERE s.invite_id = i.id) LIMIT ?)
    AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, SWEEP_DATA_BATCH, id, token, id));
  const [guard] = await env.DB.batch(stmts);
  if (!guard.meta.changes) return;
  const dependentTables = [...tables, 'invites'];
  const stillPresent = dependentTables.map(table =>
    `NOT EXISTS (SELECT 1 FROM ${table} WHERE review_id = ?)`).join(' AND ');
  const [finalGuard] = await env.DB.batch([
    sweepGuard(env, id, token),
    env.DB.prepare(`DELETE FROM reviews WHERE id = ? AND ${stillPresent}
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`)
      .bind(id, ...dependentTables.map(() => id), id, token, id),
    env.DB.prepare(`UPDATE hosted_lifecycle SET state = 'retired', committed = 0, due_at = 0
      WHERE review_id = ? AND state = 'retiring' AND ${stillPresent}
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`)
      .bind(id, ...dependentTables.map(() => id), id, token, id),
    env.DB.prepare(`DELETE FROM hosted_cleaned_storage WHERE review_id = ? AND
      EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'retired')
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, id, id, token, id),
    // Keep the deletion mark only while the gallery is not retired: it is what blocks a return to live.
    env.DB.prepare(`DELETE FROM sweep_deleting WHERE review_id = ?
      AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'retired')
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, id, id, token, id),
    // A retry row left by a failed earlier removal would otherwise outlive its review.
    env.DB.prepare(`DELETE FROM cleanup_retry WHERE review_id = ?
      AND EXISTS (SELECT 1 FROM hosted_lifecycle WHERE review_id = ? AND state = 'retired')
      AND ${CLAIM_TOKEN} AND ${SWEEP_DEADLINES}`).bind(id, id, id, token, id),
    env.DB.prepare('DELETE FROM sweep_claim WHERE review_id = ? AND token = ?').bind(id, token),
  ]);
  if (!finalGuard.meta.changes) return;
}

function metered(env) {
  const m = { rr: 0, rw: 0 };
  const add = r => { if (r && r.meta) { m.rr += r.meta.rows_read || 0; m.rw += r.meta.rows_written || 0; } return r; };
  const wrap = st => ({
    bind: (...a) => wrap(st.bind(...a)),
    first: async () => { const r = add(await st.all()); return (r.results && r.results[0]) || null; },
    all: async () => add(await st.all()),
    run: async () => add(await st.run()),
    raw: st,
  });
  const DB = { prepare: q => wrap(env.DB.prepare(q)), batch: async list => (await env.DB.batch(list.map(x => x.raw))).map(add) };
  return { env: { ...env, DB }, m };
}

export default {
  async scheduled(_event, env) {
    if (env.REVIEW_IMAGES) {
      await ensureLifecycle(env);
      await closeExpiredGalleries(env);
      await sweepHostedReview(env);
    }
  },
  async fetch(req, env) {
    if (env.BRAID_METRICS === '1') {
      const t0 = performance.now(), { env: e, m } = metered(env);
      const res = await handle(req, e);
      const h = new Headers(res.headers); h.set('x-braid-metrics', `rr=${m.rr};rw=${m.rw};ms=${(performance.now() - t0).toFixed(1)}`);
      return new Response(res.body, { status: res.status, headers: h });
    }
    return handle(req, env);
  },
};

async function handle(req, env) {
  {
    const url = new URL(req.url);
    const p = url.pathname;
    if (req.method === 'GET' && (p === '/' || p === '/app.js' || p === '/p-app.js' || p === '/marks.js' || p === '/app.css')) {
      const file = p === '/' ? '/index.html' : p === '/p-app.js' ? '/app.js' : p;
      return asset(env, req, url, file, { 'Content-Security-Policy': CSP });
    }
    // Everything below may read hosted_lifecycle; make sure a content-only upgrade has it before the first read.
    if (env.REVIEW_IMAGES) {
      try { await ensureLifecycle(env); }
      catch { return json({ error: 'storage-unavailable' }, 503); }
    }
    // Public link-preview card: served without a session, and never opens the gallery. GET and HEAD only.
    const pub = p.match(/^\/p\/([A-Za-z0-9_-]{1,64})(\/cover\.jpg)?$/);
    if (pub && (req.method === 'GET' || req.method === 'HEAD')) return publicPreview(req, env, url, pub[1], !!pub[2]);
    if (p === '/api/session' && req.method === 'POST') {
      if (!sameOrigin(req, url)) return json({ error: 'origin' }, 403);
      const b = await req.json().catch(() => null);
      if (!b || typeof b.token !== 'string' || b.token.length < 20 || b.token.length > 100) return json({ error: 'invalid' }, 403);
      const inv = await env.DB.prepare(
        `SELECT i.id, i.revoked, i.expires_at AS iexp, r.expires_at AS rexp, r.status, r.id AS review_id,
           i.expires_at < ${DB_NOW} AS i_gone, r.expires_at < ${DB_NOW} AS r_gone, ${DB_NOW} AS db_now
           FROM invites i JOIN reviews r ON r.id = i.review_id WHERE i.token_hash = ?`
      ).bind(await sha256(b.token)).first();
      if (!inv || inv.revoked || inv.status !== 'open' || inv.i_gone || inv.r_gone || await hostedIsRetired(env, inv.review_id)) return json({ error: 'invalid' }, 403);
      const sid = randomToken();
      // The insert itself re-checks the invite against the database clock: a revoke, close or expiry committed since
      // the read above leaves no session and gets no cookie.
      const insert = env.DB.prepare(`INSERT INTO sessions (id_hash, invite_id, created_at)
        SELECT ?, ?, ? WHERE EXISTS (SELECT 1 FROM invites i JOIN reviews r ON r.id = i.review_id
          WHERE i.id = ? AND r.id = ? AND i.revoked = 0 AND r.status = 'open'
          AND i.expires_at >= ${DB_NOW} AND r.expires_at >= ${DB_NOW})`)
        .bind(await sha256(sid), inv.id, inv.db_now, inv.id, inv.review_id);
      let inserted;
      if (env.REVIEW_IMAGES) {
        try { inserted = (await env.DB.batch([hostedLiveGuard(env, inv.review_id), insert]))[1]?.meta?.changes; }
        catch (error) {
          if (await hostedIsRetired(env, inv.review_id)) return json({ error: 'invalid' }, 403);
          throw error;
        }
      } else inserted = (await insert.run()).meta.changes;
      if (!inserted) return json({ error: 'invalid' }, 403);
      const maxAge = Math.max(0, Math.floor((Math.min(inv.iexp, inv.rexp) - inv.db_now) / 1000));
      // reviewId lets the page bind itself to the gallery its invite names, and refuse another tab's session.
      return json({ ok: true, reviewId: inv.review_id }, 200, { 'Set-Cookie': `brs=${sid}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}` });
    }
    if (p === '/admin/reviews' && req.method === 'POST') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return createReview(env, await req.json().catch(() => null));
    }
    if (env.REVIEW_IMAGES && p === '/admin/capabilities' && req.method === 'GET') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      const budget = hostedBudget(env);
      if (budget == null) return json({ error: 'storage-unavailable' }, 503);
      const available = await env.DB.prepare(`SELECT s.id FROM hosted_storage s
        LEFT JOIN hosted_lifecycle l ON l.review_id = '' WHERE s.id = 1`).first().catch(() => null);
      if (!available) return json({ error: 'storage-unavailable' }, 503);
      return json({ service: 'braid-review', protocolVersion: 1, storage: 'private-durable-sqlite', deleteOnlineGallery: true, restoreReviewLink: true, galleryViewerVersion: 18, cleanup: 1, adminKeys: 1, cover: 1, finish: 1, budgetBytes: budget, maxImageBytes: MAX_HOSTED_IMAGE_BYTES });
    }
    const capacityCheck = p.match(/^\/admin\/storage\/check\/([A-Za-z0-9_-]{8,64})$/);
    if (env.REVIEW_IMAGES && ((p === '/admin/storage' && req.method === 'GET') || (capacityCheck && req.method === 'POST'))) {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return hostedCapacity(env, capacityCheck?.[1], req);
    }
    const upload = p.match(/^\/admin\/assets\/([A-Za-z0-9_-]{8,64})\/(t|p)\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (env.REVIEW_IMAGES && upload && req.method === 'PUT') {
      if (!(await isAdmin(req, env))) return json({ error: 'admin-auth' }, 401);
      return uploadHostedImage(req, env, upload[1], upload[2], upload[3]);
    }
    // Grid tiles for Braid (host key): thumbnails in its conflict list.
    const hostImg = p.match(/^\/host\/([A-Za-z0-9_-]{8,64})\/img\/t\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (hostImg && req.method === 'GET') {
      const r = await hostReview(req, env, hostImg[1]);
      if (!r) return await hostRefused(env, hostImg[1]);
      // By gallery key: the tile's file name comes from the manifest (files are named by content).
      const row = await env.DB.prepare('SELECT manifest FROM reviews WHERE id = ?').bind(r.id).first();
      if (!row) return json({ error: 'not-found' }, 404);
      const img = (JSON.parse(row.manifest).images || []).find(i => i.key === hostImg[2]);
      if (!img) return json({ error: 'not-found' }, 404);
      return reviewImage(env, req, url, r.id, 't', img.thumb);
    }
    const host = p.match(/^\/host\/([A-Za-z0-9_-]{8,64})\/(marks|mark|settle|status|invites|revoke|restore-link|expire|starting|committed|delete-files|preview|finish)$/);
    // Finish is handled before hostReview, which hides every gallery past its purge deadline: a retry after a lost
    // reply must still authenticate and answer "finishing" or "gone".
    if (host && host[2] === 'finish') return finishHostedReview(req, env, host[1]);
    if (host) {
      const r = await hostReview(req, env, host[1]);
      if (!r) return await hostRefused(env, host[1]);
      // The Share card: publish (create-only), read by invite, edit the title, or switch the card off.
      if (host[2] === 'preview') {
        if (req.method === 'POST') return publishPreview(req, env, r);
        if (req.method === 'GET') {
          const inviteId = url.searchParams.get('invite') || '';
          const card = ID.test(inviteId) ? await hostPreviewCard(env, r.id, inviteId) : null;
          return card ? json(CARD_SHAPE(card)) : json({ error: 'not-found' }, 404);
        }
        if (req.method === 'PUT') return editPreview(req, env, r);
        if (req.method === 'DELETE') return deletePreview(env, r, url.searchParams.get('invite') || '');
        return json({ error: 'not-found' }, 404);
      }
      // Braid's idle read: changed marks plus the last client edit (already on the review row it authenticated with).
      if (host[2] === 'marks' && req.method === 'GET') return json({ ...(await marksSince(env, r.id, url)), lastClientEditAt: r.last_client_edit || null });
      if ((host[2] === 'starting' || host[2] === 'committed') && req.method === 'GET') return hostManage(req, env, r, host[2]);
      if ((host[2] === 'mark' || host[2] === 'settle') && req.method === 'POST') {
        const b = await req.json().catch(() => null);
        if (!validMark(b)) return json({ error: 'bad-request' }, 400);
        return host[2] === 'mark' ? commitMark(env, r.id, 'host', null, b) : settleMark(env, r.id, 'host', b);
      }
      return hostManage(req, env, r, host[2]);
    }
    const s = await sessionFor(req, env);
    if (!s) return json({ error: 'signin' }, 401);
    // A mark or cover write answers the same shape as its race path, so the viewer reads the reason from one field.
    const closedShape = (p === '/api/mark' && req.method === 'POST') || (p === '/api/cover' && req.method === 'PUT');
    if (s.denied) return json(closedShape ? { error: 'error', closed: s.denied } : { error: s.denied }, 403);
    if (p === '/api/review' && req.method === 'GET') {
      // The stored gallery list goes out as it is (no parse and re-serialise on every open); marks come from /api/marks.
      const m = await env.DB.prepare('SELECT manifest FROM reviews WHERE id = ?').bind(s.review_id).first();
      if (!m) return json({ error: 'expired' }, 403);
      // Braid's own verification read of a new share never seeds: the publish's auto-cover choice comes next.
      const cover = await reviewCover(env, s.review_id)
        || (req.headers.get('X-Braid-Verify') ? null : await seedLegacyCover(env, s.review_id));
      const meta = JSON.stringify({ reviewId: s.review_id, role: s.role, label: s.label, title: s.title, version: s.version,
        expiresAt: Math.min(s.iexp, s.rexp), cover });
      return new Response('{"manifest":' + m.manifest + ',' + meta.slice(1), { headers: { 'Content-Type': 'application/json', ...PRIVATE } });
    }
    if (p === '/api/marks' && req.method === 'GET') return json(await marksSince(env, s.review_id, url));
    if (p === '/api/cover' && req.method === 'PUT') {
      if (!sameOrigin(req, url)) return json({ error: 'origin' }, 403);
      const b = await req.json().catch(() => null);
      // reviewId is optional: an old viewer sends none and changes this session's own gallery, exactly as before.
      if (!b || (b.reviewId !== undefined && !ID.test(b.reviewId)) || !ID.test(b.imageKey || '') || !Number.isInteger(b.baseRev) || b.baseRev < 1) return json({ error: 'bad-request' }, 400);
      if (b.reviewId !== undefined && b.reviewId !== s.review_id) return json({ error: 'session-switched' }, 409);
      // ONE update: the invite's liveness, the review's openness, manifest membership and the revision all gate the
      // change, so a stale viewer refreshes instead of replaying onto a newer cover. Marks and edit time are untouched.
      // The write is always a photographer's choice, and this also migrates a pre-source table before it is touched.
      let changed = 0;
      try {
        await ensurePreviewTables(env);
        changed = (await env.DB.prepare(`UPDATE review_cover SET image_key = ?, rev = rev + 1, source = 'photographer'
          WHERE review_id = ? AND rev = ?
          AND EXISTS (SELECT 1 FROM invites i JOIN reviews r ON r.id = i.review_id
            WHERE i.id = ? AND r.id = ? AND i.revoked = 0 AND r.status = 'open'
            AND i.expires_at >= ${DB_NOW} AND r.expires_at >= ${DB_NOW})
          AND EXISTS (SELECT 1 FROM json_each((SELECT manifest FROM reviews WHERE id = ?), '$.images')
            WHERE json_extract(value, '$.key') = ?)`)
          .bind(b.imageKey, s.review_id, b.baseRev, s.invite_id, s.review_id, s.review_id, b.imageKey).run()).meta.changes;
      } catch (error) { if (!missingTable(error)) throw error; }
      if (changed) return json({ ok: true, imageKey: b.imageKey, rev: b.baseRev + 1 });
      const gone = await accessGone(env, s.review_id, s.invite_id);
      if (gone) return json({ error: 'error', closed: gone }, 403);
      return json((await reviewCover(env, s.review_id)) || { imageKey: null, rev: 0 }, 409);
    }
    if (p === '/api/mark' && req.method === 'POST') {
      if (!sameOrigin(req, url)) return json({ error: 'origin' }, 403);
      return writeMark(req, env, s);
    }
    // Images of this session's review only: grid tiles (t) and viewer images (p).
    const im = p.match(/^\/img\/(p|t)\/([A-Za-z0-9_-]{8,64})\.jpg$/);
    if (req.method === 'GET' && im) return reviewImage(env, req, url, s.review_id, im[1], im[2], { 'Cache-Control': 'private, max-age=86400, immutable' });
    return json({ error: 'not-found' }, 404);
  }
}
